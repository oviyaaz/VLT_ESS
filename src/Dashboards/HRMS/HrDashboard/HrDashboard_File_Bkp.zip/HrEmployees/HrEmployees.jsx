import { useState, useEffect, useCallback } from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import axios from "axios";
import { Edit, Trash2Icon, UserPlus } from "lucide-react";
import { toast } from "react-toastify";
import Default_img from "../images/profile.png";
// import AddEmployee from "./AddEmployee";
// import EditEmployee from "./EditEmployee";

import React from "react";


import { useForm, Controller } from "react-hook-form";




const apiBaseUrl = import.meta.env.VITE_BASE_API;

const HrEmployees = () => {
  const [employeeList, setEmployeeList] = useState([]);
  const [departmentList, setDepartmentList] = useState([]);
  const [shiftList, setShiftList] = useState([]);
  const [addEmployeePopup, setAddEmployeePopup] = useState(false);
  const [editEmployeePopup, setEditEmployeePopup] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);

  // Fetch Employee List
  const fetchEmployeeList = useCallback(async () => {
    try {
      const { data } = await axios.get(`${apiBaseUrl}/api/employee_list/`);
      setEmployeeList(
        data.map((employee) => ({
          id: employee.employee_id,
          username: employee.username,
          email: employee.email,
          role: employee.role,
          department: employee.department,
          shift: employee.shift,
          dob: employee.dob,
          hiredDate: employee.hired_date,
          gender: employee.gender,
          avatar: employee.employee_image || Default_img,
        }))
      );
    } catch (error) {
      toast.error("Failed to fetch employee list.");
    }
  }, []);

  // Fetch Department List
  const fetchDepartmentList = useCallback(async () => {
    try {
      const { data } = await axios.get(`${apiBaseUrl}/admin/overall-departments/`);
      setDepartmentList(data);
    } catch (error) {
      toast.error("Failed to fetch department list.");
    }
  }, []);

  // Fetch Shift List
  const fetchShiftList = useCallback(async () => {
    try {
      const { data } = await axios.get(`${apiBaseUrl}/admin/show-shift/`);
      setShiftList(data);
    } catch (error) {
      toast.error("Failed to fetch shift list.");
    }
  }, []);

  useEffect(() => {
    fetchEmployeeList();
    fetchDepartmentList();
    fetchShiftList();
  }, [fetchEmployeeList, fetchDepartmentList, fetchShiftList]);

  const handleEdit = (row) => {
    setSelectedEmployee(row);
    setEditEmployeePopup(true);
  };

  const handleDelete = async (row) => {
    if (!window.confirm(`Are you sure you want to delete Employee ID ${row.id}?`)) return;

    try {
      await axios.delete(`${apiBaseUrl}/admin/employees/delete/${row.id}/`);
      toast.success(`Employee ID ${row.id} deleted successfully.`);
      fetchEmployeeList();
    } catch (error) {
      toast.error("Failed to delete employee.");
    }
  };

  const columns = [
    { field: "id", headerName: "ID", width: 90 },
    {
      field: "avatar",
      headerName: "Avatar",
      width: 80,
      renderCell: (params) => (
        <div className="grid place-items-center">
          <img src={params.row.avatar || Default_img} alt={params.row.username} height={40} width={40} className="rounded-full" />
        </div>
      ),
    },
    { field: "username", headerName: "User Name", width: 200 },
    { field: "email", headerName: "Email", width: 200 },
    { field: "role", headerName: "Role", width: 150 },
    { field: "department", headerName: "Department", width: 150 },
    { field: "dob", headerName: "DOB", width: 90 },
    { field: "hiredDate", headerName: "Hired Date", width: 150 },
    { field: "gender", headerName: "Gender", width: 90 },
    {
      field: "actions",
      headerName: "Actions",
      width: 150,
      renderCell: (params) => (
        <div className="flex gap-2">
          <button className="btn-primary" onClick={() => handleEdit(params.row)}>
            <Edit />
          </button>
          <button className="btn-danger" onClick={() => handleDelete(params.row)}>
            <Trash2Icon />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="h-full min-h-screen p-6 container mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-semibold">Employee List</h3>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2" onClick={() => setAddEmployeePopup(true)}>
          <UserPlus size={20} />
          Add Employee
        </button>
      </div>

      <DataGrid
        rows={employeeList}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { pageSize: 6 },
          },
        }}
        slots={{ toolbar: GridToolbar }}
        pageSizeOptions={[5, 10, 20]}
        checkboxSelection
        disableRowSelectionOnClick
      />

      {/* Add Employee Modal */}
      {addEmployeePopup && (
        <AddEmployee setAddEmployeePopup={setAddEmployeePopup} DepartmentList={departmentList} ShiftList={shiftList} />
      )}

      {/* Update Employee Modal */}
      {editEmployeePopup && selectedEmployee && (
        <EditEmployee
          setEditEmployeePopup={setEditEmployeePopup}
          employeeId={selectedEmployee.id}
          DepartmentList={departmentList}
          ShiftList={shiftList}
          fetchEmployeeList={fetchEmployeeList}
        />
      )}
    </div>
  );
};

export default HrEmployees;



// import { useState } from "react";
// import { useForm } from "react-hook-form";
// import axios from "axios";
// import { toast } from "react-toastify";

// import { useForm, Controller } from "react-hook-form";
// import axios from "axios";
// import { toast } from "react-toastify";


const AddEmployee = ({ setAddEmployeePopup, fetchEmployeeList }) => {
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm();

  const onSubmit = async (data) => {
    try {
      const baseApiUrl = import.meta.env.VITE_BASE_API;
      const formData = new FormData();

      Object.keys(data).forEach((key) => {
        if (key === "employee_image") {
          formData.append(key, data[key][0]); // Append file
        } else {
          formData.append(key, data[key]);
        }
      });

      await axios.post(`${baseApiUrl}/admin/employees/add/`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      setAddEmployeePopup(false);
      fetchEmployeeList();
      toast.success("Employee added successfully!");
    } catch (error) {
      console.error(error);
      toast.error("Failed to add Employee");
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 z-50">
      <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-2xl mx-4">
        <h1 className="text-2xl font-semibold mb-6 text-gray-700">Add Employee</h1>

        <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
          {/* Personal Details */}
          <div className="space-y-4">
            <h2 className="font-medium text-gray-700">Personal Details</h2>

            {/* Name Field */}
            <div className="grid grid-cols-3 gap-2">
              <label className="text-sm font-medium">Name</label>
              <input
                type="text"
                placeholder="Enter name"
                className="input-style col-span-2"
                {...register("employee_name", {
                  required: "Name is required",
                  minLength: { value: 3, message: "Minimum 3 characters required" },
                  pattern: { value: /^[a-zA-Z\s]+$/, message: "Only letters and spaces allowed" },
                })}
              />
              {errors.employee_name && <span className="text-red-500 text-sm">{errors.employee_name.message}</span>}
            </div>

            {/* Email Field */}
            
            <div>
              <label className="text-sm font-medium">Email</label>
              <input
                type="email"
                placeholder="Enter Email Address"
                className="input-field"
                {...register("email", {
                  required: "Email is required",
                  pattern: { value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/, message: "Invalid email format" },
                  maxLength: { value: 100, message: "Email cannot exceed 100 characters" },
                })}
              />
              {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
            </div>

            {/* Gender Field */}
           
            <div>
              <label className="text-sm font-medium">Gender</label>
              <select
                className="input-field"
                {...register("gender", {
                  required: "Gender is required",
                })}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
              {errors.gender && <p className="text-red-500 text-sm">{errors.gender.message}</p>}
            </div>

            {/* Date of Birth */}
           
            <div>
              <label className="text-sm font-medium">Date of Birth</label>
              <input
                type="date"
                className="input-field"
                {...register("dob", {
                  required: "Date of Birth is required",
                  validate: (value) => {
                    const today = new Date();
                    const selectedDate = new Date(value);
                    const age = today.getFullYear() - selectedDate.getFullYear();
                    if (selectedDate > today) return "Future dates are not allowed";
                    if (age < 18) return "You must be at least 18 years old";
                    return true;
                  },
                })}
              />
              {errors.dob && <p className="text-red-500 text-sm">{errors.dob.message}</p>}
            </div>

            {/* Profile Image */}
            <div className="grid grid-cols-3 gap-2">
              <label className="text-sm font-medium">Profile Image</label>
              <input
                type="file"
                accept="image/*"
                className="input-style col-span-2"
                {...register("employee_image", {
                  required: "Profile image is required",
                  validate: (fileList) => {
                    if (fileList.length === 0) return "Profile image is required";
                    const file = fileList[0];
                    return file.size <= 2 * 1024 * 1024 || "File size must be less than 2MB";
                  },
                })}
              />
              {errors.employee_image && <span className="text-red-500 text-sm">{errors.employee_image.message}</span>}
            </div>
          </div>

          {/* Work Details */}
          <div className="space-y-4">
            <h2 className="font-medium text-gray-700">Work Details</h2>

            {/* User ID */}
            
            <div>
              <label className="text-sm font-medium">User ID</label>
              <input
                type="text"
                placeholder="Enter User ID"
                className="input-field"
                {...register("manager_id", {
                  required: "User ID is required",
                  minLength: { value: 5, message: "User ID must be at least 5 characters" },
                  maxLength: { value: 15, message: "User ID must be at most 15 characters" },
                  pattern: { value: /^[a-zA-Z0-9]+$/, message: "Only letters and numbers allowed" },
                })}
              />
              {errors.manager_id && <p className="text-red-500 text-sm">{errors.manager_id.message}</p>}
            </div>

            {/* Username */}
            <div className="grid grid-cols-3 gap-2">
              <label className="text-sm font-medium">Username</label>
              <input
                type="text"
                placeholder="Enter Username"
                className="input-style col-span-2"
                {...register("username", {
                  required: "Username is required",
                  pattern: { value: /^[a-zA-Z0-9_]{5,20}$/, message: "5-20 characters, letters, numbers, _" },
                })}
              />
              {errors.username && <span className="text-red-500 text-sm">{errors.username.message}</span>}
            </div>

            {/* Password */}
            <div className="grid grid-cols-3 gap-2">
              <label className="text-sm font-medium">Password</label>
              <input
                type="password"
                placeholder="Enter User Password"
                className="input-style col-span-2"
                {...register("password", {
                  required: "Password is required",
                  minLength: { value: 8, message: "Minimum 8 characters required" },
                })}
              />
              {errors.password && <span className="text-red-500 text-sm">{errors.password.message}</span>}
            </div>
          </div>

          {/* Buttons Section */}
          <div className="flex justify-end space-x-4">
            <button 
              type="button" 
              className="btn-secondary px-4 py-2 rounded-md bg-gray-300 text-gray-700 hover:bg-gray-400 transition"
              onClick={() => setAddEmployeePopup(false)}
            >
              Cancel
            </button>

            <button type="submit" className="btn-primary px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition">
              Add Employee
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};









// import axios from "axios";
// import React, { useState, useEffect } from "react";
// import { toast } from "react-toastify";
// const apiBaseUrl = process.env.VITE_BASE_API;
// import { useState, useEffect } from "react";
// import axios from "axios";
// import { toast } from "react-toastify";

const EditEmployee = ({
  setEditEmployeePopup,
  employeeId,
  ShiftList,
  DepartmentList,
  fetchEmployeeList,
  apiBaseUrl,
}) => {
  const [EmployeeData, setEmployeeData] = useState({
    employee_name: "",
    email: "",
    gender: "",
    dob: "",
    employee_image: null,
    username: "",
    password: "",
    department: "",
    shift: "",
    hired_date: "",
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    const fetchEmployeeData = async () => {
      if (!employeeId) {
        toast.error("Employee ID is missing. Please try again.");
        return;
      }
      try {
        const { data } = await axios.get(
          `${apiBaseUrl}/api/employees/${employeeId}/`
        );
        setEmployeeData({
          employee_name: data.employee_name,
          email: data.email,
          gender: data.gender,
          dob: data.dob,
          username: data.username,
          department: data.department,
          shift: data.shift,
          hired_date: data.hired_date,
          employee_image: null, // Can't preview image
        });
      } catch (error) {
        console.error("Error fetching employee data:", error);
        toast.error("Failed to fetch employee data.");
      }
    };

    fetchEmployeeData();
  }, [employeeId, apiBaseUrl]);

  const handleUpdateEmployee = async (e) => {
    e.preventDefault();

    // Form Validation
    let validationErrors = {};
    if (!EmployeeData.employee_name) validationErrors.employee_name = "Name is required";
    if (!EmployeeData.email.match(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/))
      validationErrors.email = "Enter a valid email";
    if (!EmployeeData.gender) validationErrors.gender = "Gender selection is required";
    if (!EmployeeData.dob) validationErrors.dob = "Date of Birth is required";
    if (!EmployeeData.department) validationErrors.department = "Please select a department";
    if (!EmployeeData.shift) validationErrors.shift = "Please select a shift";

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    try {
      const formData = new FormData();
      for (const key in EmployeeData) {
        formData.append(key, EmployeeData[key]);
      }

      await axios.put(
        `${apiBaseUrl}/admin/employees/${employeeId}/`,
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );

      toast.success("Employee updated successfully.");
      fetchEmployeeList(); // Refresh employee list
      setEditEmployeePopup(false);
    } catch (error) {
      console.error("Error updating Employee:", error);
      toast.error("Failed to update Employee.");
    }
  };

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
        <h1 className="text-2xl font-semibold mb-6">Update Employee</h1>
        <form className="space-y-6 w-full" onSubmit={handleUpdateEmployee}>
          <div className="grid gap-6 w-full">
            <div className="space-y-4">
              <h2 className="font-medium text-gray-700">Personal Details</h2>

              {/* Name */}
              <div className="grid grid-cols-3 items-center gap-2 w-full">
                <label className="text-sm font-medium">Name</label>
                <input
                  type="text"
                  className="col-span-2 px-3 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500"
                  value={EmployeeData.employee_name}
                  onChange={(e) =>
                    setEmployeeData({ ...EmployeeData, employee_name: e.target.value })
                  }
                />
                {errors.employee_name && <span className="text-red-500 text-sm">{errors.employee_name}</span>}
              </div>

              {/* Email */}
              <div className="grid grid-cols-3 items-center gap-2 w-full">
                <label className="text-sm font-medium">Email</label>
                <input
                  type="email"
                  className="col-span-2 px-3 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500"
                  value={EmployeeData.email}
                  onChange={(e) =>
                    setEmployeeData({ ...EmployeeData, email: e.target.value })
                  }
                />
                {errors.email && <span className="text-red-500 text-sm">{errors.email}</span>}
              </div>

              {/* Gender */}
              <div className="grid grid-cols-3 items-center gap-2 w-full">
                <label className="text-sm font-medium">Gender</label>
                <select
                  className="col-span-2 px-3 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500"
                  value={EmployeeData.gender}
                  onChange={(e) =>
                    setEmployeeData({ ...EmployeeData, gender: e.target.value })
                  }
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
                {errors.gender && <span className="text-red-500 text-sm">{errors.gender}</span>}
              </div>

              {/* Profile Image */}
              <div className="grid grid-cols-3 items-center gap-2 w-full">
                <label className="text-sm font-medium">Profile Image</label>
                <input
                  type="file"
                  accept="image/*"
                  className="col-span-2 px-3 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500"
                  onChange={(e) => setEmployeeData({ ...EmployeeData, employee_image: e.target.files[0] })}
                />
              </div>
            </div>

            {/* Work Details */}
            <div className="space-y-4">
              <h2 className="font-medium text-gray-700">Work Details</h2>

              {/* Department */}
              <div className="grid grid-cols-3 items-center gap-2 w-full">
                <label className="text-sm font-medium">Department</label>
                <select
                  className="col-span-2 px-3 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500"
                  value={EmployeeData.department}
                  onChange={(e) =>
                    setEmployeeData({ ...EmployeeData, department: e.target.value })
                  }
                >
                  <option value="">Select Department</option>
                  {DepartmentList.map((dept) => (
                    <option key={dept.id} value={dept.id}>
                      {dept.department_name}
                    </option>
                  ))}
                </select>
                {errors.department && <span className="text-red-500 text-sm">{errors.department}</span>}
              </div>

              {/* Shift */}
              <div className="grid grid-cols-3 items-center gap-2 w-full">
                <label className="text-sm font-medium">Shift</label>
                <select
                  className="col-span-2 px-3 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500"
                  value={EmployeeData.shift}
                  onChange={(e) =>
                    setEmployeeData({ ...EmployeeData, shift: e.target.value })
                  }
                >
                  <option value="">Select Shift</option>
                  {ShiftList.map((shift) => (
                    <option key={shift.id} value={shift.id}>
                      {shift.shift_name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          <div className="flex justify-end space-x-4">
            <button 
              type="button" 
              className="bg-gray-400 text-white px-4 py-2 rounded-md" 
              onClick={() => setEditEmployeePopup(false)}
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="bg-blue-500 text-white px-4 py-2 rounded-md"
            >
              Update Employee
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
