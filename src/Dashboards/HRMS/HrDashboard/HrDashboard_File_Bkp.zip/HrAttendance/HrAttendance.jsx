import React, { useState, useEffect } from "react";
import axios from "axios";

// import Header from "./Header.jsx";
// import Sidebar from "./Sidebar.jsx";
import profile from "../images/profile.png";
import up from "../images/up.png";
import down from "../images/down.png";

const baseApiUrl = import.meta.env.VITE_BASE_API;

const HrAttendance = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [attendanceData, setAttendanceData] = useState([]);
  const [managerData, setManagerData] = useState([]);
  const [attendanceType, setAttendanceType] = useState("weekly");

  const toggleSidebar = () => setIsSidebarOpen((prev) => !prev);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [attendanceResponse, managerResponse] = await Promise.all([
          axios.get(`${baseApiUrl}/api/md_manager_weekly_chart/`, {
            params: 108,
          }),
          axios.get(`${baseApiUrl}/md/md_manager_monthly_chart/`, {
            params: 108,
          }),
        ]);
        setAttendanceData(attendanceResponse.data);
        setManagerData(managerResponse.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  // Reusable Card Component
  const MetricCard = ({ title, value, trend, icon, trendText }) => (
    <div className="w-full mb-6">
      <div className="bg-white shadow-sm rounded-lg p-4">
        <div className="flex justify-between items-start">
          <div>
            <h5 className="text-lg font-semibold">{title}</h5>
            <p className="text-2xl font-bold mb-3">{value}</p>
          </div>
          <i className={`bi ${icon}`} style={{ fontSize: "40px" }}></i>
        </div>
        <p className="flex items-center text-sm mt-2">
          <img
            src={trend === "up" ? up : down}
            alt={trend}
            className="w-6 h-6 mr-2"
          />
          <span className={trend === "up" ? "text-green-600" : "text-red-600"}>
            {trendText}
          </span>{" "}
          Than average last month
        </p>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col w-full min-h-screen">
      <div id="mainContent" className="flex-1 p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Metric Cards */}
          <MetricCard
            title="Total Employees"
            value="150"
            trend="down"
            icon="bi-person-x"
            trendText="-10%"
          />
          <MetricCard
            title="Total Present"
            value="127"
            trend="up"
            icon="bi-person-check"
            trendText="+10%"
          />
          <MetricCard
            title="Total Working Hrs"
            value="120 Hrs"
            trend="down"
            icon="bi-file-earmark-text"
            trendText="-10%"
          />
        </div>

        {/* To-dos Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          {/* To-dos Card */}
          <div className="bg-white shadow-sm rounded-lg p-4">
            <div className="flex justify-between items-center mb-4">
              <h5 className="text-lg font-semibold">To-dos</h5>
              <a href="#" className="text-sm text-gray-500 hover:text-gray-700">
                6 incomplete all
              </a>
            </div>
            <ul className="list-none">
              <li className="mb-3">
                <input type="checkbox" className="mr-2" />
                Prepare company welcome kit
                <br />
                <small className="text-gray-500">
                  Upcoming 23:59 - 29 Oct 2023
                </small>
              </li>
              <li>
                <input type="checkbox" className="mr-2" />
                Collect Documents - Hard Copies
                <br />
                <small className="text-gray-500">
                  Upcoming 23:59 - 31 Oct 2023
                </small>
              </li>
            </ul>
          </div>

          {/* Who's Off Today Card */}
          <div className="bg-white shadow-sm rounded-lg p-4">
            <div className="flex justify-between items-center mb-4">
              <h5 className="text-lg font-semibold">Who's Off Today</h5>
              <a href="#" className="text-sm text-gray-500 hover:text-gray-700">
                View all
              </a>
            </div>
            <ul className="list-none">
              <li className="flex items-center mb-4">
                <img
                  src={profile}
                  className="rounded-full w-12 h-12 mr-4"
                  alt="Profile"
                />
                <div>
                  <strong className="text-sm">John Doe</strong>
                  <br />
                  <small className="text-gray-500">25 Oct - 27 Oct</small>
                </div>
              </li>
              <li className="flex items-center mb-4">
                <img
                  src={profile}
                  className="rounded-full w-12 h-12 mr-4"
                  alt="Profile"
                />
                <div>
                  <strong className="text-sm">Alexa Johns</strong>
                  <br />
                  <small className="text-gray-500">25 Oct - 27 Oct</small>
                </div>
              </li>
            </ul>
          </div>

          {/* New Members Today Card */}
          <div className="bg-white shadow-sm rounded-lg p-4">
            <h5 className="text-lg font-semibold mb-4">New Members Today</h5>
            <ul className="list-none">
              <li className="flex items-center mb-4">
                <img
                  src={profile}
                  className="rounded-full w-12 h-12 mr-4"
                  alt="Profile"
                />
                <div>
                  <strong className="text-sm">Shani Indira Natio</strong>
                  <br />
                  <small className="text-gray-500">
                    Joining on 24 Oct 2023
                  </small>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HrAttendance;
