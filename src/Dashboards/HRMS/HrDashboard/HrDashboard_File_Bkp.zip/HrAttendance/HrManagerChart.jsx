import React, { useState, useEffect } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
 
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);
const apiBaseUrl = process.env.VITE_BASE_API;
const ManagerChart = () => {
  const [managers, setManagers] = useState([]);
  const [selectedManager, setSelectedManager] = useState("");
  const [weekOffset, setWeekOffset] = useState(0);
  const [monthOffset, setMonthOffset] = useState(0);
  const [weeklyData, setWeeklyData] = useState(null);
  const [monthlyData, setMonthlyData] = useState(null);

  useEffect(() => {
    axios.get(`${apiBaseUrl}/api/manager_list/`)
      .then((response) => {
        setManagers(response.data);
      })
      .catch((error) => console.error("Error fetching managers:", error));
  }, []);

  const fetchWeeklyChart = (offset) => {
    if (!selectedManager) return;
    axios.post(`${apiBaseUrl}/api/admin-manager-weekly-chart/`, {
      manager_id: selectedManager,
      week_offset: offset,
    })
      .then((response) => {
        setWeeklyData(response.data);
      })
      .catch((error) => console.error("Error fetching weekly data:", error));
  };

  const fetchMonthlyChart = (offset) => {
    if (!selectedManager) return;
    axios.post(`${apiBaseUrl}/api/admin-manager-monthly-chart/`, {
      manager_id: selectedManager,
      month_offset: offset,
    })
      .then((response) => {
        setMonthlyData(response.data);
      })
      .catch((error) => console.error("Error fetching monthly data:", error));
  };

  const handleManagerChange = (e) => {
    setSelectedManager(e.target.value);
    setWeekOffset(0);
    setMonthOffset(0);
    fetchWeeklyChart(0);
    fetchMonthlyChart(0);
  };

  return (
    <div className="managerChart p-4 h-full flex flex-col w-full gap-4">
      {/* Employee Selection */}
      <div className="flex w-full justify-between items-center">
        <h3 className="text-h3">Manager Attendance Chart</h3>
        <select className="p-2" onChange={handleManagerChange} value={selectedManager}>
          <option value="">Select Manager</option>
          {managers.map((manager) => (
            <option key={manager.manager_id} value={manager.manager_id}>
              {manager.manager_name}
            </option>
          ))}
        </select>
      </div>

      {/* Weekly Chart */}
      <div className="weekly min-h-1/2 w-full flex flex-col gap-4">
        <div className="flex w-full justify-between items-center">
          <h3 className="text-h3">Weekly Attendance Chart</h3>
          <div>
            <button className="btn-secondary mx-2" onClick={() => {
              setWeekOffset(weekOffset - 1);
              fetchWeeklyChart(weekOffset - 1);
            }}>Previous</button>
            <button className="btn-secondary" onClick={() => {
              setWeekOffset(weekOffset + 1);
              fetchWeeklyChart(weekOffset + 1);
            }}>Next</button>
          </div>
        </div>
        <div className="h-[40dvh] bg-white">
          {weeklyData && <Bar data={{
            labels: weeklyData.labels,
            datasets: [
              { label: "Work Hours", data: weeklyData.data, backgroundColor: "blue" },
              { label: "Leave Hours", data: weeklyData.leave_data, backgroundColor: "red" }
            ]
          }} />}
        </div>
      </div>

      {/* Monthly Chart */}
      <div className="monthly h-1/2 w-full flex flex-col gap-4">
        <div className="flex w-full justify-between items-center">
          <h3 className="text-h3">Monthly Attendance Chart</h3>
          <div>
            <button className="btn-secondary mx-2" onClick={() => {
              setMonthOffset(monthOffset - 1);
              fetchMonthlyChart(monthOffset - 1);
            }}>Previous</button>
            <button className="btn-secondary" onClick={() => {
              setMonthOffset(monthOffset + 1);
              fetchMonthlyChart(monthOffset + 1);
            }}>Next</button>
          </div>
        </div>
        <div className="h-[40dvh] bg-white">
          {monthlyData && <Bar data={{
            labels: monthlyData.labels,
            datasets: [
              { label: "Work Hours", data: monthlyData.work_data, backgroundColor: "blue" },
              { label: "Leave Days", data: monthlyData.leave_data, backgroundColor: "red" }
            ]
          }} />}
        </div>
      </div>
    </div>
  );
};

export default ManagerChart;