import React from "react";
import Sidebar from "../../../components/Sidebar";
import { UserCog } from "lucide-react";
import { Outlet } from "react-router-dom";

const AttendanceLink = [
  {
    path: "/hr/attendance",
    label: "Employee Feedback",
    icon: <UserCog />,
  },
  {
    path: "/hr/attendance/managerChart",
    label: "Manager Chart",
    icon: <UserCog />,
  },
  {
    path: "/hr/attendance/employeeChart",
    label: "Employee Chart",
    icon: <UserCog />,
  },
];

const HrAttendanceLayout = () => {
  return (
    <div className="EmployeeManagement flex w-full">
      <Sidebar NavPaths={AttendanceLink} />
      <Outlet />
    </div>
  );
};

export default HrAttendanceLayout;
