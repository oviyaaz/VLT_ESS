import React from "react";
import { Outlet } from "react-router-dom";
import HRHeader from "./HrHeader";

const HRLayout = () => {
  return (
    <div className="flex w-full min-h-dvh">
      {/* <AdminSideBar /> */}
      <div className="w-full relative">
        {/* <AdminHeader {...user} /> */}
        <HRHeader />
        <Outlet />
      </div>
    </div>
  );
};

export default HRLayout;
