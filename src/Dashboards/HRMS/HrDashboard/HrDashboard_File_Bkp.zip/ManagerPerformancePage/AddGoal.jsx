import axios from "axios";
import React, { useState } from "react";
import { toast } from "react-toastify";
import { useForm } from "react-hook-form";

const apiBaseUrl = process.env.VITE_BASE_API;

const AddGoal = ({ setAddGoalPopup, ManagerList, fetchGoalList }) => {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();

  const onSubmit = async (formData) => {
    try {
      await axios.post(`${apiBaseUrl}/api/create_goal_manager/`, formData, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      setAddGoalPopup(false);
      fetchGoalList(); // Refresh the list after adding a goal
      toast.success("Goal added successfully!");
    } catch (error) {
      console.error("Error adding Goal:", error);
      const errorMessage = error.response?.data?.error || "Failed to add Goal";
      toast.error(errorMessage);
    }
  };

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
        <h1 className="text-2xl font-semibold mb-6">Add Manager Goal</h1>

        {/* React Hook Form: handleSubmit is used for validation */}
        <form className="space-y-6 w-full" onSubmit={handleSubmit(onSubmit)}>
          <div className="grid gap-6 w-full">
            <div className="space-y-4">
              <h2 className="font-medium text-gray-700">Goal Details</h2>
              <div className="space-y-4">
                {/* Manager Selection */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="manager" className="text-sm font-medium">
                    Manager Name
                  </label>
                  <select
                    id="manager"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.manager ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("manager", { required: "Manager is required" })}
                  >
                    <option value="">Select Manager</option>
                    {ManagerList.map((manager) => (
                      <option key={manager.id} value={manager.id}>
                        {manager.manager_name}
                      </option>
                    ))}
                  </select>
                  {errors.manager && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.manager.message}
                    </span>
                  )}
                </div>

                {/* Goal Text */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="goal_text" className="text-sm font-medium">
                    Goal Text
                  </label>
                  <input
                    type="text"
                    id="goal_text"
                    placeholder="Enter goal description"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.goal_text ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("goal_text", {
                      required: "Goal text is required",
                      minLength: { value: 5, message: "Minimum 5 characters required" },
                      pattern: {
                        value: /^[A-Za-z0-9.,!? ]+$/,
                        message: "Invalid characters in goal text",
                      },
                    })}
                  />
                  {errors.goal_text && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.goal_text.message}
                    </span>
                  )}
                </div>

                {/* Start Date */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="start_date" className="text-sm font-medium">
                    Start Date
                  </label>
                  <input
                    type="date"
                    id="start_date"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.start_date ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("start_date", { required: "Start date is required" })}
                  />
                  {errors.start_date && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.start_date.message}
                    </span>
                  )}
                </div>

                {/* End Date */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="end_date" className="text-sm font-medium">
                    End Date
                  </label>
                  <input
                    type="date"
                    id="end_date"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.end_date ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("end_date", { required: "End date is required" })}
                  />
                  {errors.end_date && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.end_date.message}
                    </span>
                  )}
                </div>

                {/* Is Completed Checkbox */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="is_completed" className="text-sm font-medium">
                    Is Completed
                  </label>
                  <div className="col-span-2 flex items-center gap-4">
                    <input
                      type="checkbox"
                      id="is_completed"
                      className="hidden"
                      {...register("is_completed")}
                    />
                    <button
                      type="button"
                      className={`px-4 py-2 text-sm font-medium rounded-lg ${
                        watch("is_completed") ? "bg-green-500 text-white" : "bg-red-500 text-white"
                      }`}
                      onClick={() =>
                        register("is_completed").onChange({
                          target: { name: "is_completed", value: !watch("is_completed") },
                        })
                      }
                    >
                      {watch("is_completed") ? "Yes" : "No"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-4 mt-8">
            <button
              type="button"
              onClick={() => setAddGoalPopup(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddGoal;
