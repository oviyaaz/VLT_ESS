import axios from "axios";
import React from "react";
import { toast } from "react-toastify";
import { useForm } from "react-hook-form";

const apiBaseUrl = process.env.VITE_BASE_API;

const AddReview = ({ setAddReviewPopup, ManagerList, fetchReviewList }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: {
      manager: "",
      comments: "",
      review_date: "",
      score: "",
    },
  });

  const onSubmit = async (data) => {
    try {
      const { manager, comments, review_date, score } = data;
      const reviewData = {
        manager,
        comments,
        review_date,
        score,
      };

      const res = await axios.post(`${apiBaseUrl}/reviews/`, reviewData, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      console.log(res.data);
      setAddReviewPopup(false);
      fetchReviewList(); // Refresh the list after adding a review
      toast.success("Review added successfully!");
      reset(); // Reset form after submission
    } catch (error) {
      console.error("Error adding review:", error);
      const errorMessage =
        error.response?.data?.error || "Failed to add review";
      toast.error(errorMessage);
    }
  };

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
        <h1 className="text-2xl font-semibold mb-6">Add Manager Performance Review</h1>
        <form className="space-y-6 w-full" onSubmit={handleSubmit(onSubmit)}>
          <div className="grid gap-6 w-full">
            <div className="space-y-4">
              <h2 className="font-medium text-gray-700">Review Details</h2>
              <div className="space-y-4">
                {/* Manager Name Field */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="manager" className="text-sm font-medium">
                    Manager Name
                  </label>
                  <select
                    id="manager"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.manager ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("manager", { required: "Manager is required" })}
                  >
                    <option value="" disabled>
                      Select Manager
                    </option>
                    {ManagerList.map((manager) => (
                      <option key={manager.manager_id} value={manager.manager_id}>
                        {manager.manager_name}
                      </option>
                    ))}
                  </select>
                  {errors.manager && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.manager.message}
                    </span>
                  )}
                </div>

                {/* Comments Field */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="comments" className="text-sm font-medium">
                    Comments
                  </label>
                  <textarea
                    id="comments"
                    placeholder="Enter description"
                    className={`w-full px-3 py-2 rounded-md border resize-none ${
                      errors.comments ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("comments", {
                      required: "Comments are required",
                      pattern: {
                        value: /^[a-zA-Z0-9\s.,!?'-]+$/, // Allows letters, numbers, and punctuation
                        message: "Only letters, numbers, and punctuation are allowed",
                      },
                      minLength: {
                        value: 10,
                        message: "Comments must be at least 10 characters",
                      },
                      maxLength: {
                        value: 500,
                        message: "Comments cannot exceed 500 characters",
                      },
                    })}
                  />
                  {errors.comments && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.comments.message}
                    </span>
                  )}
                </div>

                {/* Review Date Field */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="review_date" className="text-sm font-medium">
                    Review Date
                  </label>
                  <input
                    type="date"
                    id="review_date"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.review_date ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("review_date", {
                      required: "Review date is required",
                      validate: (value) =>
                        new Date(value) <= new Date() || "Review date cannot be in the future",
                    })}
                  />
                  {errors.review_date && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.review_date.message}
                    </span>
                  )}
                </div>

                {/* Score Field */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="score" className="text-sm font-medium">
                    Score (Out of 10)
                  </label>
                  <input
                    type="number"
                    id="score"
                    min="0"
                    max="10"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.score ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("score", {
                      required: "Score is required",
                      valueAsNumber: true,
                      min: { value: 0, message: "Score must be at least 0" },
                      max: { value: 10, message: "Score cannot exceed 10" },
                    })}
                  />
                  {errors.score && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.score.message}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-4 mt-8">
            <button
              type="button"
              onClick={() => setAddReviewPopup(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddReview;
