import axios from "axios";
import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { useForm } from "react-hook-form";

const apiBaseUrl = process.env.VITE_BASE_API;

const UpdateGoal = ({ setUpdateGoalPopup, goalId, ManagerList, fetchGoalList }) => {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  const [GoalData, setGoalData] = useState({
    manager: "",
    goal_text: "",
    start_date: "",
    end_date: "",
    is_completed: false,
  });

  useEffect(() => {
    const fetchGoalData = async () => {
      if (!goalId) {
        console.error("Goal ID is undefined");
        toast.error("Goal ID is missing. Please try again.");
        return;
      }
      try {
        const { data } = await axios.get(`${apiBaseUrl}/goals-manager/${goalId}/`);
        setGoalData({
          id: data.id,
          manager: data.manager.manager_id, // Use ID instead of name
          goal_text: data.goal_text,
          start_date: data.start_date,
          end_date: data.end_date,
          is_completed: data.is_completed,
        });

        // Set default values for react-hook-form
        setValue("manager", data.manager.manager_id);
        setValue("goal_text", data.goal_text);
        setValue("start_date", data.start_date);
        setValue("end_date", data.end_date);
        setValue("is_completed", data.is_completed);
      } catch (error) {
        console.error("Error fetching goal data:", error);
        toast.error("Failed to fetch goal data.");
      }
    };

    fetchGoalData();
  }, [goalId, setValue]);

  const onSubmit = async (data) => {
    try {
      const formattedData = {
        ...data,
        start_date: new Date(data.start_date).toISOString().split("T")[0],
        end_date: new Date(data.end_date).toISOString().split("T")[0],
        is_completed: data.is_completed === true,
      };

      await axios.put(
        `${apiBaseUrl}/admin/update-manager-goal/${goalId}/`,
        formattedData,
        {
          headers: { "Content-Type": "application/json" },
        }
      );

      toast.success("Goal updated successfully.");
      fetchGoalList();
      setUpdateGoalPopup(false);
    } catch (error) {
      console.error("Error updating Goal:", error);
      toast.error(
        error.response?.data?.errors
          ? Object.values(error.response.data.errors).flat().join(", ")
          : "Failed to update Goal."
      );
    }
  };

  return (
    <>
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
          <h1 className="text-2xl font-semibold mb-6">Update Manager Goal</h1>
          <form className="space-y-6 w-full" onSubmit={handleSubmit(onSubmit)}>
            <div className="grid gap-6 w-full">
              <div className="space-y-4">
                <h2 className="font-medium text-gray-700">Goal Details</h2>
                <div className="space-y-4">
                  {/* Manager Name */}
                  <div className="grid grid-cols-3 items-center gap-2 w-full">
                    <label htmlFor="manager" className="text-sm font-medium">
                      Manager Name
                    </label>
                    <select
                      id="manager"
                      className={`w-full px-3 py-2 rounded-md border ${
                        errors.manager ? "border-red-500" : "border-gray-300"
                      } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                      {...register("manager", { required: "Manager is required" })}
                    >
                      <option value="" disabled>
                        Select Manager
                      </option>
                      {ManagerList.map((manager) => (
                        <option key={manager.manager_id} value={manager.manager_id}>
                          {manager.manager_name}
                        </option>
                      ))}
                    </select>
                    {errors.manager && (
                      <span className="text-red-500 col-span-3 text-sm">
                        {errors.manager.message}
                      </span>
                    )}
                  </div>

                  {/* Goal Text */}
                  <div className="grid grid-cols-3 items-center gap-2 w-full">
                    <label htmlFor="goal_text" className="text-sm font-medium">
                      Goal Text
                    </label>
                    <input
                      type="text"
                      id="goal_text"
                      placeholder="Enter goal description"
                      className={`w-full px-3 py-2 rounded-md border ${
                        errors.goal_text ? "border-red-500" : "border-gray-300"
                      } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                      {...register("goal_text", {
                        required: "Goal text is required",
                        minLength: {
                          value: 5,
                          message: "Goal text must be at least 5 characters long",
                        },
                        maxLength: {
                          value: 200,
                          message: "Goal text cannot exceed 200 characters",
                        },
                      })}
                    />
                    {errors.goal_text && (
                      <span className="text-red-500 col-span-3 text-sm">
                        {errors.goal_text.message}
                      </span>
                    )}
                  </div>

                  {/* Start Date */}
                  <div className="grid grid-cols-3 items-center gap-2 w-full">
                    <label htmlFor="start_date" className="text-sm font-medium">
                      Start Date
                    </label>
                    <input
                      type="date"
                      id="start_date"
                      className={`w-full px-3 py-2 rounded-md border ${
                        errors.start_date ? "border-red-500" : "border-gray-300"
                      } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                      {...register("start_date", { required: "Start date is required" })}
                    />
                    {errors.start_date && (
                      <span className="text-red-500 col-span-3 text-sm">
                        {errors.start_date.message}
                      </span>
                    )}
                  </div>

                  {/* End Date */}
                  <div className="grid grid-cols-3 items-center gap-2 w-full">
                    <label htmlFor="end_date" className="text-sm font-medium">
                      End Date
                    </label>
                    <input
                      type="date"
                      id="end_date"
                      className={`w-full px-3 py-2 rounded-md border ${
                        errors.end_date ? "border-red-500" : "border-gray-300"
                      } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                      {...register("end_date", { required: "End date is required" })}
                    />
                    {errors.end_date && (
                      <span className="text-red-500 col-span-3 text-sm">
                        {errors.end_date.message}
                      </span>
                    )}
                  </div>

                  {/* Is Completed */}
                  <div className="grid grid-cols-3 items-center gap-2 w-full">
                    <label htmlFor="is_completed" className="text-sm font-medium">
                      Is Completed
                    </label>
                    <input
                      type="checkbox"
                      id="is_completed"
                      {...register("is_completed")}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-4 mt-8">
              <button type="button" onClick={() => setUpdateGoalPopup(false)}>
                Cancel
              </button>
              <button type="submit">
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default UpdateGoal;
