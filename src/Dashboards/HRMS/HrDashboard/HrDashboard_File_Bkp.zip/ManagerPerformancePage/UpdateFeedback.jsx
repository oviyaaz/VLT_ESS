import axios from "axios";
import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";

const apiBaseUrl = process.env.VITE_BASE_API;

const UpdateFeedback = ({ setUpdateFeedbackPopup, feedbackId, ManagerList, fetchFeedbackList }) => {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm({ mode: "onChange" }); // Validate fields as the user types

  useEffect(() => {
    const fetchFeedbackData = async () => {
      if (!feedbackId) {
        console.error("Feedback ID is undefined");
        toast.error("Feedback ID is missing. Please try again.");
        return;
      }
      try {
        const { data } = await axios.get(`${apiBaseUrl}/feedbacks/manager/${feedbackId}/`);
        setValue("to_manager", data.to_manager?.id || "");
        setValue("comments", data.comments || "");
        setValue("feedback_date", data.feedback_date || "");
      } catch (error) {
        console.error("Error fetching feedback data:", error);
        toast.error("Failed to fetch feedback data.");
      }
    };

    fetchFeedbackData();
  }, [feedbackId, setValue]);

  const handleUpdateFeedback = async (formData) => {
    try {
      const formattedData = {
        ...formData,
        feedback_date: new Date(formData.feedback_date).toISOString().split("T")[0],
      };

      await axios.put(`${apiBaseUrl}/update_manager_feedback/${feedbackId}/`, formattedData, {
        headers: { "Content-Type": "application/json" },
      });

      toast.success("Feedback updated successfully.");
      fetchFeedbackList();
      setUpdateFeedbackPopup(false);
    } catch (error) {
      console.error("Error updating Feedback:", error);
      toast.error("Failed to update feedback.");
    }
  };

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
        <h1 className="text-2xl font-semibold mb-6">Update Manager Feedback</h1>
        <form className="space-y-6 w-full" onSubmit={handleSubmit(handleUpdateFeedback)}>
          <div className="grid gap-6 w-full">
            <div className="space-y-4">
              <h2 className="font-medium text-gray-700">Feedback Details</h2>
              <div className="space-y-4">
                {/* Manager Name */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label className="text-sm font-medium">Manager Name</label>
                  <select
                    className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                    {...register("to_manager", { required: "Manager is required" })}
                  >
                    <option value="" disabled>Select Manager</option>
                    {ManagerList.map((manager) => (
                      <option key={manager.id} value={manager.id}>
                        {manager.manager_name}
                      </option>
                    ))}
                  </select>
                  {errors.to_manager && (
                    <p className="text-red-500 text-xs col-span-3">{errors.to_manager.message}</p>
                  )}
                </div>

                {/* Comments */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label className="text-sm font-medium">Comments</label>
                  <input
                    type="text"
                    placeholder="Enter comments"
                    className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                    {...register("comments", {
                      required: "Comments are required",
                      maxLength: { value: 500, message: "Max length is 500 characters" },
                    })}
                  />
                  {errors.comments && (
                    <p className="text-red-500 text-xs col-span-3">{errors.comments.message}</p>
                  )}
                </div>

                {/* Feedback Date */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label className="text-sm font-medium">Feedback Date</label>
                  <input
                    type="date"
                    className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                    {...register("feedback_date", { required: "Feedback date is required" })}
                  />
                  {errors.feedback_date && (
                    <p className="text-red-500 text-xs col-span-3">{errors.feedback_date.message}</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-4 mt-8">
            <button
              type="button"
              onClick={() => setUpdateFeedbackPopup(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UpdateFeedback;
