import axios from "axios";
import React from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";

const apiBaseUrl = process.env.VITE_BASE_API;

const AddFeedback = ({ setAddFeedbackPopup, ManagerList, fetchFeedbackList }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();

  const HandleAddFeedback = async (data) => {
    try {
      await axios.post(`${apiBaseUrl}/api/create_feedback_manager/`, data, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      setAddFeedbackPopup(false);
      fetchFeedbackList();
      toast.success("Feedback added successfully!");
      reset(); // Reset form after submission
    } catch (error) {
      console.error("Error adding Feedback:", error);
      const errorMessage = error.response?.data?.error || "Failed to add Feedback";
      toast.error(errorMessage);
    }
  };

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
        <h1 className="text-2xl font-semibold mb-6">Add Manager Feedback</h1>
        <form className="space-y-6 w-full" onSubmit={handleSubmit(HandleAddFeedback)}>
          <div className="grid gap-6 w-full">
            <div className="space-y-4">
              <h2 className="font-medium text-gray-700">Feedback Details</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label className="text-sm font-medium">Manager Name</label>
                  <select
                    {...register("to_manager", { required: "Manager is required" })}
                    className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                  >
                    <option value="">Select Manager</option>
                    {ManagerList.map((manager) => (
                      <option key={manager.id} value={manager.id}>
                        {manager.manager_name}
                      </option>
                    ))}
                  </select>
                  {errors.to_manager && <p className="text-red-500 text-sm col-span-3">{errors.to_manager.message}</p>}
                </div>

                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label className="text-sm font-medium">Comments</label>
                  <input
                    type="text"
                    {...register("comments", { required: "Comments are required" })}
                    placeholder="Enter description"
                    className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                  />
                  {errors.comments && <p className="text-red-500 text-sm col-span-3">{errors.comments.message}</p>}
                </div>

                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label className="text-sm font-medium">Feedback Date</label>
                  <input
                    type="date"
                    {...register("feedback_date", { required: "Date is required" })}
                    className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                  />
                  {errors.feedback_date && <p className="text-red-500 text-sm col-span-3">{errors.feedback_date.message}</p>}
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-4 mt-8">
            <button
              type="button"
              onClick={() => setAddFeedbackPopup(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddFeedback;
