import axios from "axios";
import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { useForm } from "react-hook-form";

const apiBaseUrl = process.env.VITE_BASE_API;

const UpdateReview = ({ setUpdateReviewPopup, reviewId, ManagerList, fetchReviewList }) => {
  const { register, handleSubmit, formState: { errors }, setValue } = useForm();

  useEffect(() => {
    const fetchReviewData = async () => {
      if (!reviewId) {
        console.error("Review ID is undefined");
        toast.error("Review ID is missing. Please try again.");
        return;
      }
      try {
        const { data } = await axios.get(
          $`{apiBaseUrl}/get-reviews/${reviewId}/`
        );
        setValue("manager", data.manager.manager_id);
        setValue("comments", data.comments);
        setValue("review_date", data.review_date);
        setValue("score", data.score);
      } catch (error) {
        console.error("Error fetching review data:", error);
        toast.error("Failed to fetch review data.");
      }
    };

    fetchReviewData();
  }, [reviewId, setValue]);

  const onSubmit = async (data) => {
    try {
      const formattedData = {
        ...data,
        review_date: new Date(data.review_date).toISOString().split("T")[0],
      };

      const formData = new FormData();
      for (const key in formattedData) {
        formData.append(key, formattedData[key]);
      }

      const { data: response } = await axios.put(
        $`{apiBaseUrl}/update-reviews/${reviewId}/`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      toast.success("Review updated successfully.");
      fetchReviewList(); // Refresh the list
      setUpdateReviewPopup(false);
    } catch (error) {
      console.error("Error updating Review:", error);
      toast.error(
        error.response?.data?.errors
          ? Object.values(error.response.data.errors).flat().join(", ")
          : "Failed to update Review."
      );
    }
  };

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
        <h1 className="text-2xl font-semibold mb-6">
          Update Manager Performance Review
        </h1>
        <form className="space-y-6 w-full" onSubmit={handleSubmit(onSubmit)}>
          <div className="grid gap-6 w-full">
            <div className="space-y-4">
              <h2 className="font-medium text-gray-700">Review Details</h2>
              <div className="space-y-4">
                {/* Manager Name Field */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="manager" className="text-sm font-medium">
                    Manager Name
                  </label>
                  <select
                    id="manager"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.manager ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("manager", { required: "Manager is required" })}
                  >
                    <option value="" disabled>
                      Select Manager
                    </option>
                    {ManagerList.map((manager) => (
                      <option key={manager.manager_id} value={manager.manager_id}>
                        {manager.manager_name}
                      </option>
                    ))}
                  </select>
                  {errors.manager && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.manager.message}
                    </span>
                  )}
                </div>

                {/* Comments Field */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="comments" className="text-sm font-medium">
                    Comments
                  </label>
                  <input
                    type="text"
                    id="comments"
                    placeholder="Enter description"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.comments ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("comments", {
                      required: "Comments are required",
                      pattern: {
                        value: /^[a-zA-Z\s]+$/,
                        message: "Only letters and spaces are allowed in comments",
                      },
                      minLength: {
                        value: 10,
                        message: "Comments must be at least 10 characters",
                      },
                      maxLength: {
                        value: 500,
                        message: "Comments cannot exceed 500 characters",
                      },
                    })}
                  />
                  {errors.comments && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.comments.message}
                    </span>
                  )}
                </div>

                {/* Review Date Field */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="review_date" className="text-sm font-medium">
                    Review Date
                  </label>
                  <input
                    type="date"
                    id="review_date"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.review_date ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("review_date", {
                      required: "Review date is required",
                    })}
                  />
                  {errors.review_date && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.review_date.message}
                    </span>
                  )}
                </div>

                {/* Score Field */}
                <div className="grid grid-cols-3 items-center gap-2 w-full">
                  <label htmlFor="score" className="text-sm font-medium">
                    Score (Out of 10)
                  </label>
                  <input
                    type="number"
                    id="score"
                    min="0"
                    max="10"
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.score ? "border-red-500" : "border-gray-300"
                    } focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2`}
                    {...register("score", {
                      required: "Score is required",
                      min: { value: 0, message: "Score must be at least 0" },
                      max: { value: 10, message: "Score cannot exceed 10" },
                    })}
                  />
                  {errors.score && (
                    <span className="text-red-500 col-span-3 text-sm">
                      {errors.score.message}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-4 mt-8">
            <button
              type="button"
              onClick={() => setUpdateReviewPopup(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UpdateReview;