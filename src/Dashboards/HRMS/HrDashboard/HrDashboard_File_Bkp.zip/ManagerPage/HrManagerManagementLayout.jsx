import React from 'react'
import { Outlet } from 'react-router-dom'
import Sidebar from '../../../components/Sidebar'
import { ChartArea, UserCheck, UserCog, Users } from 'lucide-react'

const managerLink = [
  {
    path: './',
    label: 'Manager',
    icon: <Users />
  },
  {
    path: './attendance',
    label: 'Attendance',
    icon: <UserCheck />
  },
  {
    path: './attendanceReset',
    label: 'Attendance Reset',
    icon:<UserCog/>
  },
  // {
  //   path: './Chart',
  //   label: 'Statistics',
  //   icon:<ChartArea/>
  // }
]

const HrManagerManagementLayout = () => {
  return (
    <div className="ManagerManagement flex">
      <Sidebar NavPaths={managerLink} />
      <Outlet />
    </div>
  )
}

export default HrManagerManagementLayout