import React, { useEffect, useState } from "react";
import axios from "axios";
import { Table, TableHead, TableRow, TableCell, TableBody, Button } from "@mui/material";
const apiBaseUrl = process.env.VITE_BASE_API;
const HrManagerAttendanceReset = () => {
  const [resetRequests, setResetRequests] = useState([]);

  // Fetch reset requests
  const fetchResetRequests = async () => {
    try {
      const response = await axios.get(`${apiBaseUrl}/admin/manager-reset-requests/`);
      setResetRequests(response.data.reset_requests);
    } catch (error) {
      console.error("Error fetching reset requests:", error);
    }
  };

  useEffect(() => {
    fetchResetRequests();
  }, []);

  // Approve request
  const handleApprove = async (requestId) => {
    try {
      await axios.post(
        `${apiBaseUrl}/admin/approve-and-reset-checkout-time/${requestId}/`
      );
      alert("Request approved successfully");
      fetchResetRequests(); // Refresh data
    } catch (error) {
      console.error("Error approving request:", error);
    }
  };

  // Reject request
  const handleReject = async (requestId) => {
    try {
      await axios.post(
        `${apiBaseUrl}/admin/reject-reset-request/${requestId}/`
      );
      alert("Request rejected successfully");
      fetchResetRequests(); // Refresh data
    } catch (error) {
      console.error("Error rejecting request:", error);
    }
  };

  return (
    <div>
      <h2>Manager Attendance Reset Requests</h2>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>ID</TableCell>
            <TableCell>Manager ID</TableCell>
            <TableCell>Username</TableCell>
            <TableCell>Request Type</TableCell>
            <TableCell>Request Description</TableCell>
            <TableCell>Date</TableCell>
            <TableCell>Shift</TableCell>
            <TableCell>Time In</TableCell>
            <TableCell>Time Out</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {resetRequests.map((request) => (
            <TableRow key={request.id}>
              <TableCell>{request.id}</TableCell>
              <TableCell>{request.manager_id}</TableCell>
              <TableCell>{request.username}</TableCell>
              <TableCell>{request.request_type}</TableCell>
              <TableCell>{request.request_description}</TableCell>
              <TableCell>{request.date}</TableCell>
              <TableCell>{request.shift || "N/A"}</TableCell>
              <TableCell>{request.time_in || "N/A"}</TableCell>
              <TableCell>{request.time_out || "N/A"}</TableCell>
              <TableCell>{request.status}</TableCell>
              <TableCell>
                <Button
                  variant="contained"
                  color="success"
                  onClick={() => handleApprove(request.id)}
                  disabled={request.status !== "Pending"}
                >
                  Approve
                </Button>
                <Button
                  variant="contained"
                  color="error"
                  onClick={() => handleReject(request.id)}
                  disabled={request.status !== "Pending"}
                  style={{ marginLeft: "10px" }}
                >
                  Reject
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default HrManagerAttendanceReset;
