import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Card,
  CardContent,
  CardHeader,
  Avatar,
  CircularProgress,
  Alert,
  Grid,
} from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import axios from "axios";
const apiBaseUrl = process.env.VITE_BASE_API;
const ManagerAttendanceRecords = ({ managerId }) => {
  const [attendanceList, setAttendanceList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAttendanceList = async () => {
      if (managerId) {
        setLoading(true);
        setError(null); // Reset error state
        try {
          const { data } = await axios.get(
            `${apiBaseUrl}/admin/manager-attendance-history/`,
            {
              params: { manager_id: managerId }, // Pass manager_id as a query param
            }
          );
          setAttendanceList(
            data.all_records.map((record, index) => ({
              id: `${managerId}-${record.date}-${index}`,
              ...record,
            }))
          );
        } catch (error) {
          setError("Failed to fetch attendance records. Please try again.");
        } finally {
          setLoading(false);
        }
      }
    };

    fetchAttendanceList();
  }, [managerId]);

  const columns = [
    { field: "id", headerName: "ID", width: 120 },
    { field: "manager_name", headerName: "Manager Name", width: 150 },
    { field: "date", headerName: "Date", width: 120 },
    { field: "type", headerName: "Type", width: 100 },
    { field: "time_in", headerName: "Time In", width: 120 },
    { field: "time_out", headerName: "Time Out", width: 120 },
    { field: "in_status", headerName: "In Status", width: 120 },
    { field: "out_status", headerName: "Out Status", width: 120 },
    { field: "overtime", headerName: "Total Working Hours", width: 150 },
    { field: "total_working_hours", headerName: "Overtime", width: 150 },
  ];

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="300px">
        <CircularProgress size={60} color="primary" />
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="300px">
        <Alert severity="error" sx={{ fontSize: "1rem" }}>
          {error}
        </Alert>
      </Box>
    );
  }

  if (attendanceList.length === 0) {
    return (
      <Typography variant="h6" textAlign="center" color="text.secondary" sx={{ py: 2 }}>
        No attendance records available for this manager.
      </Typography>
    );
  }

  return (
    <Card elevation={3} sx={{ p: 2, borderRadius: 3, boxShadow: 2 }}>
      <Typography variant="h6" sx={{ mb: 2, fontWeight: "bold" }}>
        Attendance Records
      </Typography>
      <div style={{ height: 500, width: "100%" }}>
        <DataGrid
          rows={attendanceList}
          columns={columns}
          components={{ Toolbar: GridToolbar }}
          pageSizeOptions={[5, 10, 15]}
          sx={{
            borderRadius: 2,
            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: "#f0f0f0",
              fontWeight: "bold",
            },
            "& .MuiDataGrid-row:hover": {
              backgroundColor: "#f9f9f9",
            },
          }}
        />
      </div>
    </Card>
  );
};

const HrManagerAttendance = () => {
  const [managers, setManagers] = useState([]);
  const [selectedManagerId, setSelectedManagerId] = useState("");
  const [loadingManagers, setLoadingManagers] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchManagers = async () => {
      setLoadingManagers(true);
      setError(null); // Reset error state
      try {
        const { data } = await axios.get(`${apiBaseUrl}/api/manager_list/`);
        setManagers(data); // Assuming data is an array of managers
      } catch (error) {
        setError("Failed to fetch manager list. Please try again.");
      } finally {
        setLoadingManagers(false);
      }
    };

    fetchManagers();
  }, []);

  return (
    <Box
      p={4}
      mx="auto"
      maxWidth="lg"
      sx={{ backgroundColor: "#f5f5f5", borderRadius: 3 }}
    >
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Card
            elevation={3}
            sx={{
              p: 3,
              background: "linear-gradient(45deg, #1976D2, #42A5F5)",
              color: "white",
            }}
          >
            <CardHeader
              avatar={
                <Avatar sx={{ bgcolor: "white", color: "#1976D2" }}>
                  MA
                </Avatar>
              }
              title={
                <Typography variant="h5" fontWeight="bold">
                  Manager Attendance
                </Typography>
              }
              subheader="Track manager attendance records with ease"
              subheaderTypographyProps={{ color: "white" }}
            />
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Card elevation={3} sx={{ p: 3 }}>
            <Box display="flex" justifyContent="center" alignItems="center" mb={3}>
              <FormControl sx={{ minWidth: 300 }}>
                <InputLabel id="manager-select-label">Select a Manager</InputLabel>
                <Select
                  labelId="manager-select-label"
                  value={selectedManagerId}
                  onChange={(e) => setSelectedManagerId(e.target.value)}
                  disabled={loadingManagers}
                  sx={{ backgroundColor: "white" }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {loadingManagers ? (
                    <MenuItem disabled>
                      <CircularProgress size={20} />
                    </MenuItem>
                  ) : error ? (
                    <MenuItem disabled>
                      <Typography variant="body2" color="error">
                        {error}
                      </Typography>
                    </MenuItem>
                  ) : (
                    managers.map((manager) => (
                      <MenuItem key={manager.manager_id} value={manager.manager_id}>
                        {manager.manager_name}
                      </MenuItem>
                    ))
                  )}
                </Select>
              </FormControl>
            </Box>
          </Card>
        </Grid>

        <Grid item xs={12}>
          {selectedManagerId ? (
            <ManagerAttendanceRecords managerId={selectedManagerId} />
          ) : (
            <Card sx={{ p: 2, textAlign: "center" }}>
              <Typography variant="h6" color="text.secondary">
                Please select a manager to view attendance records.
              </Typography>
            </Card>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default HrManagerAttendance;
