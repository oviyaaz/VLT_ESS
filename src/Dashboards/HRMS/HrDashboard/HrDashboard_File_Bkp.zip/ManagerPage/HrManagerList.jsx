import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import axios from "axios";
import { Edit, Trash2Icon, UserPlus } from "lucide-react";
import React, { useEffect, useState } from "react";
import AddManager from "./AddManager";
import UpdateManager from "./UpdateManager";
// import Default_img from "../../../assets/Images/Default_user_image.png";
import { toast } from "react-toastify";

const apiBaseUrl = process.env.VITE_BASE_API;

const HrManagerList = () => {
  const [managerList, setManagerList] = useState([]);
  const [departmentList, setDepartmentList] = useState([]);
  const [shiftList, setShiftList] = useState([]);
  const [addManagerPopup, setAddManagerPopup] = useState(false);
  const [updateManagerPopup, setUpdateManagerPopup] = useState(false);
  const [selectedManager, setSelectedManager] = useState(null);

  const fetchManagerList = async () => {
    const { data } = await axios.get(`${apiBaseUrl}/api/manager_list/`);
    setManagerList(
      data.map((manager) => ({
        id: manager.manager_id,
        manager_name: manager.manager_name,
        username: manager.username,
        email: manager.email,
        role: manager.role,
        department_name: manager.department_name,
        shift: manager.shift,
        dob: manager.dob,
        hiredDate: manager.hired_date,
        gender: manager.gender,
        avatar: manager.manager_image,
      }))
    );
  };

  const fetchDepartmentList = async () => {
    const { data } = await axios.get(
      `${apiBaseUrl}/admin/overall-departments/`
    );
    setDepartmentList(data);
  };

  const fetchShiftList = async () => {
    const { data } = await axios.get(`${apiBaseUrl}/admin/show-shift/`);
    setShiftList(data);
  };

  useEffect(() => {
    fetchManagerList();
    fetchDepartmentList();
    fetchShiftList();
  }, []);

  const handleEdit = (row) => {
    setSelectedManager(row);
    setUpdateManagerPopup(true);
  };

  const handleDelete = async (row) => {
    try {
      await axios.delete(`${apiBaseUrl}/admin/managers/delete/${row.id}/`);
      toast.success(`Manager ID ${row.id} deleted successfully.`);
      fetchManagerList();
    } catch (error) {
      toast.error("Failed to delete manager.");
    }
  };

  const columns = [
    { field: "id", headerName: "ID", width: 90 },
    {
      field: "avatar",
      headerName: "Avatar",
      width: 80,
      renderCell: (params) => (
        <div className="grid place-items-center">
          <img
            src={params.row.avatar || Default_img}
            alt={params.row.username}
            height={40}
            width={40}
            className="rounded-full"
          />
        </div>
      ),
    },
    { field: "manager_name", headerName: "Name", width: 200 },
    { field: "username", headerName: "User Name", width: 200 },
    { field: "email", headerName: "Email", width: 200 },
    { field: "role", headerName: "Role", width: 150 },
    { field: "department_name", headerName: "Department", width: 150 },
    { field: "shift", headerName: "Shift", width: 150 },
    { field: "dob", headerName: "DOB", width: 90 },
    { field: "hiredDate", headerName: "Hired Date", width: 150 },
    { field: "gender", headerName: "Gender", width: 90 },
    {
      field: "actions",
      headerName: "Actions",
      width: 150,
      renderCell: (params) => (
        <div className="flex gap-2">
          <button className="btn-primary" onClick={() => handleEdit(params.row)}>
            <Edit />
          </button>
          <button
            className="btn-danger"
            onClick={() => handleDelete(params.row)}
          >
            <Trash2Icon />
          </button>
        </div>
      ),
    },
  ];

  return (
    <>
      <div className="h-full min-h-screen p-6 container mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-semibold">Manager List</h3>
          <button
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
            onClick={() => setAddManagerPopup(true)}
          >
            <UserPlus size={20} />
            Add Manager
          </button>
        </div>

        <DataGrid
          rows={managerList}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: {
                pageSize: 6,
              },
            },
          }}
          slots={{ toolbar: GridToolbar }}
          pageSizeOptions={[5, 10, 20]}
          checkboxSelection
          disableRowSelectionOnClick
        />

        {/* Add Manager Modal */}
        {addManagerPopup && (
          <AddManager
            setAddManagerPopup={setAddManagerPopup}
            DepartmentList={departmentList}
            ShiftList={shiftList}
          />
        )}

        {/* Update Manager Modal */}
        {updateManagerPopup && selectedManager && (
         <UpdateManager
          setUpdateManagerPopup={setUpdateManagerPopup}
           managerId={selectedManager.id} // Pass managerId explicitly
           DepartmentList={departmentList}
           ShiftList={shiftList}
           fetchManagerList={fetchManagerList}
         />
        )}
      </div>
    </>
  );
};

export default HrManagerList;
