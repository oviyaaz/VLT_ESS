import axios from "axios";
import React from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";

const apiBaseUrl = import.meta.env.VITE_BASE_API;

const AddManager = ({ setAddManagerPopup, ShiftList, DepartmentList }) => {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  const HandleAddManager = async (data) => {
    try {
      const formData = new FormData();
      Object.keys(data).forEach((key) => {
        if (key === "manager_image" && data.manager_image.length > 0) {
          formData.append(key, data.manager_image[0]); // Ensure file is sent correctly
        } else {
          formData.append(key, data[key]);
        }
      });

      const response = await axios.post(`${apiBaseUrl}/admin/managers/add/`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setAddManagerPopup(false);
      toast.success(`${response.data}`);
    } catch (error) {
      console.error(error);
      toast.error("Failed to add Manager");
    }
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
    const maxSize = 2 * 1024 * 1024; // 2MB

    if (!file) {
      toast.error("Profile image is required");
      return;
    }
    if (!allowedTypes.includes(file.type)) {
      toast.error("Only JPG, JPEG, and PNG formats are allowed");
      return;
    }
    if (file.size > maxSize) {
      toast.error("File size must be less than 2MB");
      return;
    }

    setValue("manager_image", event.target.files);
  };

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
        <h1 className="text-2xl font-semibold mb-6">Add Manager</h1>
        <form className="space-y-6 w-full" onSubmit={handleSubmit(HandleAddManager)}>
          <div className="grid gap-6 w-full">
            {/* Name */}
            <div>
              <label className="text-sm font-medium">Name</label>
              <input
                type="text"
                placeholder="Enter name"
                className="input-field"
                {...register("manager_name", {
                  required: "Name is required",
                  minLength: { value: 3, message: "Name must be at least 3 characters" },
                  maxLength: { value: 50, message: "Name cannot exceed 50 characters" },
                  pattern: { value: /^[A-Za-z\s]+$/, message: "Only letters and spaces allowed" },
                })}
              />
              {errors.manager_name && <p className="text-red-500 text-sm">{errors.manager_name.message}</p>}
            </div>

            {/* Email */}
            <div>
              <label className="text-sm font-medium">Email</label>
              <input
                type="email"
                placeholder="Enter Email Address"
                className="input-field"
                {...register("email", {
                  required: "Email is required",
                  pattern: { value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/, message: "Invalid email format" },
                  maxLength: { value: 100, message: "Email cannot exceed 100 characters" },
                })}
              />
              {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
            </div>

            {/* Gender */}
            <div>
              <label className="text-sm font-medium">Gender</label>
              <select
                className="input-field"
                {...register("gender", {
                  required: "Gender is required",
                })}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
              {errors.gender && <p className="text-red-500 text-sm">{errors.gender.message}</p>}
            </div>

            {/* Date of Birth */}
            <div>
              <label className="text-sm font-medium">Date of Birth</label>
              <input
                type="date"
                className="input-field"
                {...register("dob", {
                  required: "Date of Birth is required",
                  validate: (value) => {
                    const today = new Date();
                    const selectedDate = new Date(value);
                    const age = today.getFullYear() - selectedDate.getFullYear();
                    if (selectedDate > today) return "Future dates are not allowed";
                    if (age < 18) return "You must be at least 18 years old";
                    return true;
                  },
                })}
              />
              {errors.dob && <p className="text-red-500 text-sm">{errors.dob.message}</p>}
            </div>

            {/* Profile Image */}
            <div>
              <label className="text-sm font-medium">Profile Image</label>
              <input type="file" accept="image/*" className="input-field" onChange={handleFileChange} />
            </div>

            {/* User ID */}
            <div>
              <label className="text-sm font-medium">User ID</label>
              <input
                type="text"
                placeholder="Enter User ID"
                className="input-field"
                {...register("manager_id", {
                  required: "User ID is required",
                  minLength: { value: 5, message: "User ID must be at least 5 characters" },
                  maxLength: { value: 15, message: "User ID must be at most 15 characters" },
                  pattern: { value: /^[a-zA-Z0-9]+$/, message: "Only letters and numbers allowed" },
                })}
              />
              {errors.manager_id && <p className="text-red-500 text-sm">{errors.manager_id.message}</p>}
            </div>

            {/* Department */}
            <div>
              <label className="text-sm font-medium">Department</label>
              <select className="input-field" {...register("department", { required: "Please select a department" })}>
                <option value="">Select Department</option>
                {DepartmentList.map((dept) => (
                  <option key={dept.id} value={dept.id}>
                    {dept.department_name}
                  </option>
                ))}
              </select>
              {errors.department && <p className="text-red-500 text-sm">{errors.department.message}</p>}
            </div>

            {/* Shift */}
            <div>
              <label className="text-sm font-medium">Shift</label>
              <select className="input-field" {...register("shift", { required: "Please select a shift" })}>
                <option value="">Select Shift</option>
                {ShiftList.map((shift) => (
                  <option key={shift.id} value={shift.id}>
                    {shift.shift_number}
                  </option>
                ))}
              </select>
              {errors.shift && <p className="text-red-500 text-sm">{errors.shift.message}</p>}
            </div>

            {/* Buttons */}
            <div className="flex justify-end gap-4 mt-8">
              <button onClick={() => setAddManagerPopup(false)} className="btn-cancel">
                Cancel
              </button>
              <button type="submit" className="btn-submit">
                Add Manager
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddManager;
