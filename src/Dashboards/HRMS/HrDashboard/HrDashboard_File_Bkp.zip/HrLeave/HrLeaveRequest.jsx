import { X } from "lucide-react";
import React, { useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { useForm } from 'react-hook-form';

const apiBaseUrl = process.env.VITE_BASE_API;
axios.defaults.withCredentials = true;
const userInfo = JSON.parse(localStorage.getItem('userdata'));

const HrLeaveRequest = ({ setIsOpenRequest }) => {
  const { register, handleSubmit, formState: { errors }, getValues } = useForm();
  
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [leaveType, setLeaveType] = useState("");
  const [leaveReason, setLeaveReason] = useState("");

  const onSubmit = async (data) => {
    try {
      const formData = new FormData();
      formData.append("start_date", data.startDate);
      formData.append("end_date", data.endDate);
      formData.append("leave_type", data.leaveType);
      formData.append("reason", data.leaveReason);
      formData.append("user", userInfo.hr_name);
      formData.append("user_id", userInfo.hr_id);
      formData.append("email", userInfo.email);

      const res = await axios.post(
        $`{apiBaseUrl}/hr-apply-leave/`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      console.log(res.data);
      toast.success("Leave applied successfully");
      setIsOpenRequest(false);
    } catch (error) {
      console.error(error);
      toast.error("Leave application failed");
    }
  };

  return (
    <div className="absolute bg-blue-100 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
      <div className="flex flex-col p-4 border border-blue-200 rounded-lg gap-4">
        <div className="flex justify-between items-center">
          <h2 className="font-semibold">Request Leave</h2>
          
        </div>
        
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="form-group grid grid-cols-2 items-center">
            <label htmlFor="leave-start-date">Start Date</label>
            <input
              type="date"
              id="leave-start-date"
              className="p-2"
              {...register("startDate", {
                required: "Start date is required",
                validate: {
                  futureDate: (value) => {
                    const selectedDate = new Date(value);
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    return selectedDate >= today || "Start date must be today or in the future";
                  },
                },
              })}
            />
            {errors.startDate && <span className="text-red-500">{errors.startDate.message}</span>}
          </div>
          
          <div className="form-group grid grid-cols-2 items-center">
            <label htmlFor="leave-end-date">End Date</label>
            <input
              type="date"
              id="leave-end-date"
              className="p-2"
              {...register("endDate", {
                required: "End date is required",
                validate: (value) => {
                  const startDate = new Date(getValues("startDate"));
                  const endDate = new Date(value);
                  return endDate >= startDate || "End date must be after start date";
                },
              })}
            />
            {errors.endDate && <span className="text-red-500">{errors.endDate.message}</span>}
          </div>
          
          <div className="form-group grid grid-cols-2 items-center">
            <label htmlFor="leave-type">Select Leave Type</label>
            <select
              id="leave-type"
              className="p-2"
              {...register("leaveType", { required: "Leave type is required" })}
            >
              <option value="" disabled>Select Leave Type</option>
              <option value="Medical">Medical Leave</option>
              <option value="Vacation">Vacation Leave</option>
              <option value="Personal">Personal Leave</option>
            </select>
            {errors.leaveType && <span className="text-red-500">{errors.leaveType.message}</span>}
          </div>
          
          <div className="form-group grid grid-cols-2 items-center">
            <label htmlFor="leave-Reason">Reason</label>
            <textarea
              id="leave-Reason"
              className="p-2"
              placeholder="Type Reason"
              {...register("leaveReason", {
                required: "Reason is required",
                pattern: {
                  value: /^[A-Za-z\s.,!?']+$/,
                  message: "Reason should only contain letters and spaces",
                },
                minLength: {
                  value: 10,
                  message: "Reason must be at least 10 characters long",
                },
                maxLength: {
                  value: 500,
                  message: "Reason cannot exceed 500 characters",
                },
              })}
            ></textarea>
            {errors.leaveReason && <span className="text-red-500">{errors.leaveReason.message}</span>}
          </div>

          <div className="footer-request flex justify-end items-center mt-8">
            <button type="button" className="btn-secondary" onClick={() => setIsOpenRequest(false)}>Cancel</button>
            <button type="submit" className="btn-primary ml-2">Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default HrLeaveRequest;