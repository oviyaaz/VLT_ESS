import React, { useEffect, useState } from "react";
import axios from "axios";

import "react-calendar/dist/Calendar.css";
import "@fortawesome/fontawesome-free/css/all.min.css";
import TaskChart from "./TaskChart.jsx";
import Ticket_chart from "./Ticket_chart.jsx";

const HrHelpDesk = () => {
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen((prev) => !prev);
  };

  const fetchTicket = async () => {
    try {
      const baseApiUrl = import.meta.env.VITE_BASE_API;
      if (!baseApiUrl) {
        throw new Error("Base API URL is not defined in environment variables.");
      }

      const apiUrl = `${baseApiUrl}/tickets/`;
      const response = await axios.get(apiUrl);

      if (!response.data) {
        throw new Error("No data received from API.");
      }

      setData(response.data);
    } catch (error) {
      setError(error);
      console.error("Error fetching tickets:", error);
    }
  };

  useEffect(() => {
    fetchTicket();
  }, []);

  const calculateMetrics = () => {
    const today = new Date().toISOString().split("T")[0];

    const ticketsCreatedToday = data.filter(
      (ticket) => ticket.created_on.split("T")[0] === today
    ).length;

    const ticketsClosedToday = data.filter(
      (ticket) =>
        ticket.status.toLowerCase() === "close" &&
        ticket.last_updated.split("T")[0] === today
    ).length;

    const openTickets = data.filter(
      (ticket) => ticket.status.toLowerCase() === "open"
    ).length;

    const openTicketsLast30Days = data.filter((ticket) => {
      const createdDate = new Date(ticket.created_on);
      const todayDate = new Date();
      const diffDays = (todayDate - createdDate) / (1000 * 60 * 60 * 24);
      return diffDays <= 30 && ticket.status.toLowerCase() === "open";
    }).length;

    // Calculate Avg. First Response Time
    const firstResponseTimes = data
      .filter((ticket) => ticket.first_response_time && ticket.created_on)
      .map((ticket) => {
        const createdTime = new Date(ticket.created_on);
        const firstResponseTime = new Date(ticket.first_response_time);
        return (firstResponseTime - createdTime) / (1000 * 60); // in minutes
      });

    const avgFirstResponseTime =
      firstResponseTimes.length > 0
        ? (
            firstResponseTimes.reduce((a, b) => a + b, 0) / firstResponseTimes.length
          ).toFixed(2)
        : "N/A";

    // Calculate Avg. Resolution Time
    const resolutionTimes = data
      .filter((ticket) => ticket.resolution_time && ticket.created_on)
      .map((ticket) => {
        const createdTime = new Date(ticket.created_on);
        const resolutionTime = new Date(ticket.resolution_time);
        return (resolutionTime - createdTime) / (1000 * 60); // in minutes
      });

    const avgResolutionTime =
      resolutionTimes.length > 0
        ? (
            resolutionTimes.reduce((a, b) => a + b, 0) / resolutionTimes.length
          ).toFixed(2)
        : "N/A";

    return {
      ticketsCreatedToday,
      ticketsClosedToday,
      openTickets,
      openTicketsLast30Days,
      avgFirstResponseTime,
      avgResolutionTime,
    };
  };

  const {
    ticketsCreatedToday,
    ticketsClosedToday,
    openTickets,
    openTicketsLast30Days,
    avgFirstResponseTime,
    avgResolutionTime,
  } = calculateMetrics();

  return (
    <div className="flex">
      <div className="flex-1 p-6">
        <div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Metric Cards */}
            <div className="card flex flex-col bg-white shadow-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="font-semibold text-lg">Tickets Created Today</h5>
                  <p className="text-3xl font-bold">{ticketsCreatedToday}</p>
                </div>
                <i className="bi bi-file-earmark-text text-4xl text-gray-600"></i>
              </div>
            </div>

            <div className="card flex flex-col bg-white shadow-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="font-semibold text-lg">Tickets Closed Today</h5>
                  <p className="text-3xl font-bold">{ticketsClosedToday}</p>
                </div>
                <i className="bi bi-file-earmark-text text-4xl text-gray-600"></i>
              </div>
            </div>

            <div className="card flex flex-col bg-white shadow-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="font-semibold text-lg">Open Tickets</h5>
                  <p className="text-3xl font-bold">{openTickets}</p>
                </div>
                <i className="bi bi-file-earmark-text text-4xl text-gray-600"></i>
              </div>
            </div>

            <div className="card flex flex-col bg-white shadow-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="font-semibold text-lg">
                    Open Tickets (Last 30 days)
                  </h5>
                  <p className="text-3xl font-bold">{openTicketsLast30Days}</p>
                </div>
                <i className="bi bi-file-earmark-text text-4xl text-gray-600"></i>
              </div>
            </div>

            <div className="card flex flex-col bg-white shadow-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="font-semibold text-lg">
                    Avg. First Response Time (Last 30 days)
                  </h5>
                  <p className="text-3xl font-bold">{avgFirstResponseTime} mins</p>
                </div>
                <i className="bi bi-clock text-4xl text-gray-600"></i>
              </div>
            </div>

            <div className="card flex flex-col bg-white shadow-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="font-semibold text-lg">
                    Avg. Resolution Time (Last 30 days)
                  </h5>
                  <p className="text-3xl font-bold">{avgResolutionTime} mins</p>
                </div>
                <i className="bi bi-clock-history text-4xl text-gray-600"></i>
              </div>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Task Chart */}
            <div className="bg-white shadow-lg rounded-lg p-4">
              <h5 className="font-bold text-xl mb-4">Task Chart</h5>
              <TaskChart />
            </div>

            {/* Ticket Chart */}
            <div className="bg-white shadow-lg rounded-lg p-4 col-span-2">
              <Ticket_chart />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HrHelpDesk;
