import { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { Edit, Trash2Icon, UserPlus } from "lucide-react";
// import Default_img from "../../../assets/Images/Default_user_image.png";
import AddSupervisor from "./AddSupervisor";
import UpdateSupervisor from "./UpdateSupervisor";

const HrSupervisorList = () => {
  const [supervisorList, setSupervisorList] = useState([]);
  const [departmentList, setDepartmentList] = useState([]);
  const [shiftList, setShiftList] = useState([]);
  const [addSupervisorPopup, setAddSupervisorPopup] = useState(false);
  const [updateSupervisorPopup, setUpdateSupervisorPopup] = useState(false);
  const [selectedSupervisor, setSelectedSupervisor] = useState(null);

  const apiBaseUrl = process.env.VITE_BASE_API;

  // Fetch department list
  const fetchDepartmentList = async () => {
    try {
      const { data } = await axios.get(
        `${apiBaseUrl}/admin/overall-departments/`
      );
      setDepartmentList(data);
    } catch (error) {
      console.error("Failed to fetch department list:", error);
    }
  };

  // Fetch supervisor list and map department ID to name
  const fetchSupervisorList = async () => {
    try {
      const { data } = await axios.get(`${apiBaseUrl}/api/supervisor_list/`);
      setSupervisorList(
        data.map((supervisor) => {
          const departmentName =
            departmentList.find((dept) => dept.id === supervisor.department)
              ?.department_name || "Unknown Department";
          return {
            id: supervisor.supervisor_id,
            username: supervisor.username,
            email: supervisor.email,
            role: supervisor.role,
            department_name: departmentName, // Correctly map the department name
            shift: supervisor.shift,
            dob: supervisor.dob,
            hiredDate: supervisor.hired_date,
            gender: supervisor.gender,
            avatar: supervisor.supervisor_image,
          };
        })
      );
    } catch (error) {
      console.error("Failed to fetch supervisor list:", error);
    }
  };

  // Fetch shift list
  const fetchShiftList = async () => {
    try {
      const { data } = await axios.get(`${apiBaseUrl}/admin/show-shift/`);
      setShiftList(data);
    } catch (error) {
      console.error("Failed to fetch shift list:", error);
    }
  };

  // Fetch all data on initial load
  useEffect(() => {
    fetchDepartmentList(); // Fetch departments first
  }, []);

  useEffect(() => {
    if (departmentList.length) {
      fetchSupervisorList(); // Fetch supervisors after department list is available
      fetchShiftList(); // Fetch shifts
    }
  }, [departmentList]); // Trigger this effect when departmentList is updated

  const handleEdit = (row) => {
    setSelectedSupervisor(row);
    setUpdateSupervisorPopup(true);
  };

  const handleDelete = async (row) => {
    try {
      await axios.delete(`${apiBaseUrl}/admin/supervisor/delete/${row.id}/`);
      toast.success(`Supervisor ID ${row.id} deleted successfully.`);
      fetchSupervisorList();
    } catch (error) {
      toast.error("Failed to delete supervisor.");
    }
  };

  const columns = [
    { field: "id", headerName: "ID", width: 90 },
    {
      field: "avatar",
      headerName: "Avatar",
      width: 80,
      renderCell: (params) => (
        <div className="grid place-items-center">
          <img
            src={params.row.avatar || Default_img}
            alt={params.row.username}
            height={40}
            width={40}
            className="rounded-full"
          />
        </div>
      ),
    },
    { field: "username", headerName: "User Name", width: 200 },
    { field: "email", headerName: "Email", width: 200 },
    { field: "role", headerName: "Role", width: 150 },
    { field: "department_name", headerName: "Department", width: 150 }, // Ensure this field is properly referenced
    { field: "shift", headerName: "Shift", width: 150 },
    { field: "dob", headerName: "DOB", width: 90 },
    { field: "hiredDate", headerName: "Hired Date", width: 150 },
    { field: "gender", headerName: "Gender", width: 90 },
    {
      field: "actions",
      headerName: "Actions",
      width: 150,
      renderCell: (params) => (
        <div className="flex gap-2">
          <button
            className="btn-primary"
            onClick={() => handleEdit(params.row)}
          >
            <Edit />
          </button>
          <button
            className="btn-danger"
            onClick={() => handleDelete(params.row)}
          >
            <Trash2Icon />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="h-full min-h-screen p-6 container mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-semibold">Supervisor List</h3>
        <button
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
          onClick={() => setAddSupervisorPopup(true)}
        >
          <UserPlus size={20} />
          Add Supervisor
        </button>
      </div>

      <DataGrid
        rows={supervisorList}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 6,
            },
          },
        }}
        slots={{ toolbar: GridToolbar }}
        pageSizeOptions={[5, 10, 20]}
        checkboxSelection
        disableRowSelectionOnClick
      />

      {/* Add Supervisor Modal */}
      {addSupervisorPopup && (
        <AddSupervisor
          setAddSupervisorPopup={setAddSupervisorPopup}
          DepartmentList={departmentList}
          ShiftList={shiftList}
        />
      )}

      {/* Update Supervisor Modal */}
      {updateSupervisorPopup && selectedSupervisor && (
        <UpdateSupervisor
          setUpdateSupervisorPopup={setUpdateSupervisorPopup}
          supervisorId={selectedSupervisor.id}
          DepartmentList={departmentList}
          ShiftList={shiftList}
          fetchSupervisorList={fetchSupervisorList}
        />
      )}
    </div>
  );
};

export default HrSupervisorList;
