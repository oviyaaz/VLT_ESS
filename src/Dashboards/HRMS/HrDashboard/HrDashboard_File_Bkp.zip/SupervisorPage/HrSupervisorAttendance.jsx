import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Paper,
  Card,
  CardContent,
  CardHeader,
  CircularProgress,
  Alert,
  Avatar,
  Grid,
} from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import axios from "axios";

const HrSupervisorAttendanceRecords = ({ supervisorId }) => {
  const [attendanceList, setAttendanceList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const apiBaseUrl = process.env.VITE_BASE_API;

  useEffect(() => {
    const fetchAttendanceList = async () => {
      if (!supervisorId) return; // Don't fetch if supervisorId is not selected

      setLoading(true);
      setError(null); // Reset error state
      try {
        const { data } = await axios.get(
          `${apiBaseUrl}/admin/supervisor-attendance-history/`,
          {
            params: { supervisor_id: supervisorId },
          }
        );
        setAttendanceList(
          data.all_records.map((record, index) => ({
            id: `${supervisorId}-${record.date}-${index}`,
            ...record,
          }))
        );
      } catch (error) {
        setError("Failed to fetch attendance records. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchAttendanceList();
  }, [supervisorId]);

  const columns = [
    { field: "date", headerName: "Date", width: 130 },
    { field: "type", headerName: "Type", width: 120 },
    { field: "time_in", headerName: "Time In", width: 130 },
    { field: "time_out", headerName: "Time Out", width: 130 },
    { field: "in_status", headerName: "In Status", width: 150 },
    { field: "out_status", headerName: "Out Status", width: 150 },
    {
      field: "total_working_hours",
      headerName: "Total Working Hours",
      width: 200,
    },
    { field: "overtime", headerName: "Overtime", width: 200 },
  ];

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="300px"
      >
        <CircularProgress size={60} color="primary" />
      </Box>
    );
  }

  if (error) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="300px"
      >
        <Alert severity="error" sx={{ fontSize: "1rem" }}>
          {error}
        </Alert>
      </Box>
    );
  }

  if (attendanceList.length === 0) {
    return (
      <Typography
        variant="h6"
        textAlign="center"
        color="text.secondary"
        sx={{ py: 2 }}
      >
        No attendance records available for this supervisor.
      </Typography>
    );
  }

  return (
    <Card elevation={3} sx={{ p: 2, borderRadius: 3, boxShadow: 2 }}>
      <Typography variant="h6" sx={{ mb: 2, fontWeight: "bold" }}>
        Attendance Records
      </Typography>
      <div style={{ height: 400, width: "100%" }}>
        <DataGrid
          rows={attendanceList}
          columns={columns}
          components={{ Toolbar: GridToolbar }}
          pageSizeOptions={[5, 10, 15]}
          sx={{
            borderRadius: 2,
            "& .MuiDataGrid-columnHeaders": {
              backgroundColor: "#f0f0f0",
              fontWeight: "bold",
            },
            "& .MuiDataGrid-row:hover": {
              backgroundColor: "#f9f9f9",
            },
          }}
        />
      </div>
    </Card>
  );
};

const HrSupervisorAttendance = () => {
  const [supervisors, setSupervisors] = useState([]);
  const [selectedSupervisorId, setSelectedSupervisorId] = useState("");
  const [loadingSupervisors, setLoadingSupervisors] = useState(false);
  const [error, setError] = useState(null);
  const apiBaseUrl = process.env.VITE_BASE_API;

  useEffect(() => {
    const fetchSupervisors = async () => {
      setLoadingSupervisors(true);
      setError(null); // Reset error state
      try {
        const { data } = await axios.get(`${apiBaseUrl}/api/supervisor_list/`);
        if (Array.isArray(data)) {
          setSupervisors(data);
        } else {
          setError("Unexpected response format. Please contact support.");
        }
      } catch (error) {
        setError("Failed to fetch supervisor list. Please try again.");
      } finally {
        setLoadingSupervisors(false);
      }
    };

    fetchSupervisors();
  }, []);

  return (
    <Box
      p={4}
      mx="auto"
      maxWidth="lg"
      sx={{ backgroundColor: "#f5f5f5", borderRadius: 3 }}
    >
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Card
            elevation={3}
            sx={{
              p: 3,
              background: "linear-gradient(45deg, #1976D2, #42A5F5)",
              color: "white",
            }}
          >
            <CardHeader
              avatar={
                <Avatar sx={{ bgcolor: "white", color: "#1976D2" }}>SA</Avatar>
              }
              title={
                <Typography variant="h5" fontWeight="bold">
                  Supervisor Attendance
                </Typography>
              }
              subheader="Track supervisor attendance records with ease"
              subheaderTypographyProps={{ color: "white" }}
            />
          </Card>
        </Grid>

        <Grid item xs={12}>
          <Card elevation={3} sx={{ p: 3 }}>
            <Box
              display="flex"
              justifyContent="center"
              alignItems="center"
              mb={3}
            >
              <FormControl sx={{ minWidth: 300 }}>
                <InputLabel id="supervisor-select-label">
                  Select a Supervisor
                </InputLabel>
                <Select
                  labelId="supervisor-select-label"
                  value={selectedSupervisorId}
                  onChange={(e) => setSelectedSupervisorId(e.target.value)}
                  disabled={loadingSupervisors}
                  sx={{ backgroundColor: "white" }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {loadingSupervisors ? (
                    <MenuItem disabled>
                      <CircularProgress size={20} />
                    </MenuItem>
                  ) : error ? (
                    <MenuItem disabled>
                      <Typography variant="body2" color="error">
                        {error}
                      </Typography>
                    </MenuItem>
                  ) : (
                    Array.isArray(supervisors) &&
                    supervisors.map((supervisor) => (
                      <MenuItem
                        key={supervisor.supervisor_id}
                        value={supervisor.supervisor_id}
                      >
                        {supervisor.supervisor_name}
                      </MenuItem>
                    ))
                  )}
                </Select>
              </FormControl>
            </Box>
          </Card>
        </Grid>

        <Grid item xs={12}>
          {selectedSupervisorId ? (
            <HrSupervisorAttendanceRecords
              supervisorId={selectedSupervisorId}
            />
          ) : (
            <Card sx={{ p: 2, textAlign: "center" }}>
              <Typography variant="h6" color="text.secondary">
                Please select a supervisor to view attendance records.
              </Typography>
            </Card>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default HrSupervisorAttendance;
