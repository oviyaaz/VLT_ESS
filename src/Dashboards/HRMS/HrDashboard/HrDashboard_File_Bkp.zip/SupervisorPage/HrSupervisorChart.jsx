import React, { useState, useEffect } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);
const apiBaseUrl = process.env.VITE_BASE_API;
const HrSupervisorChart = () => {
  const [supervisors, setSupervisors] = useState([]);
  const [selectedSupervisor, setSelectedSupervisor] = useState("");
  const [weekOffset, setWeekOffset] = useState(0);
  const [monthOffset, setMonthOffset] = useState(0);
  const [weeklyData, setWeeklyData] = useState(null);
  const [monthlyData, setMonthlyData] = useState(null);

  useEffect(() => {
    axios
      .get(`${apiBaseUrl}/api/supervisor_list/`)
      .then((response) => {
        setSupervisors(response.data);
      })
      .catch((error) => console.error("Error fetching supervisors:", error));
  }, []);

  const fetchWeeklyChart = (offset) => {
    if (!selectedSupervisor) return;
    axios
      .post(`${apiBaseUrl}/api/admin-supervisor-weekly-chart/`, {
        supervisor_id: selectedSupervisor,
        week_offset: offset,
      })
      .then((response) => {
        setWeeklyData(response.data);
      })
      .catch((error) => console.error("Error fetching weekly data:", error));
  };

  const fetchMonthlyChart = (offset) => {
    if (!selectedSupervisor) return;
    axios
      .post(`${apiBaseUrl}/api/admin-supervisor-monthly-chart/`, {
        supervisor_id: selectedSupervisor,
        month_offset: offset,
      })
      .then((response) => {
        setMonthlyData(response.data);
      })
      .catch((error) => console.error("Error fetching monthly data:", error));
  };

  const handleSupervisorChange = (e) => {
    setSelectedSupervisor(e.target.value);
    setWeekOffset(0);
    setMonthOffset(0);
    fetchWeeklyChart(0);
    fetchMonthlyChart(0);
  };

  return (
    <div className="supervisorChart p-4 h-full flex flex-col w-full gap-4">
      {/* Supervisor Selection */}
      <div className="flex w-full justify-between items-center">
        <h3 className="text-h3">Supervisor Attendance Chart</h3>
        <select
          className="p-2"
          onChange={handleSupervisorChange}
          value={selectedSupervisor}
        >
          <option value="">Select Supervisor</option>
          {supervisors.map((supervisor) => (
            <option
              key={supervisor.supervisor_id}
              value={supervisor.supervisor_id}
            >
              {supervisor.supervisor_name}
            </option>
          ))}
        </select>
      </div>

      {/* Weekly Chart */}
      <div className="weekly min-h-1/2 w-full flex flex-col gap-4">
        <div className="flex w-full justify-between items-center">
          <h3 className="text-h3">Weekly Attendance Chart</h3>
          <div>
            <button
              className="btn-secondary mx-2"
              onClick={() => {
                setWeekOffset(weekOffset - 1);
                fetchWeeklyChart(weekOffset - 1);
              }}
            >
              Previous
            </button>
            <button
              className="btn-secondary"
              onClick={() => {
                setWeekOffset(weekOffset + 1);
                fetchWeeklyChart(weekOffset + 1);
              }}
            >
              Next
            </button>
          </div>
        </div>
        <div className="h-[40dvh] bg-white">
          {weeklyData && (
            <Bar
              data={{
                labels: weeklyData.labels,
                datasets: [
                  {
                    label: "Work Hours",
                    data: weeklyData.data,
                    backgroundColor: "blue",
                  },
                  {
                    label: "Leave Hours",
                    data: weeklyData.leave_data,
                    backgroundColor: "red",
                  },
                ],
              }}
            />
          )}
        </div>
      </div>

      {/* Monthly Chart */}
      <div className="monthly h-1/2 w-full flex flex-col gap-4">
        <div className="flex w-full justify-between items-center">
          <h3 className="text-h3">Monthly Attendance Chart</h3>
          <div>
            <button
              className="btn-secondary mx-2"
              onClick={() => {
                setMonthOffset(monthOffset - 1);
                fetchMonthlyChart(monthOffset - 1);
              }}
            >
              Previous
            </button>
            <button
              className="btn-secondary"
              onClick={() => {
                setMonthOffset(monthOffset + 1);
                fetchMonthlyChart(monthOffset + 1);
              }}
            >
              Next
            </button>
          </div>
        </div>
        <div className="h-[40dvh] bg-white">
          {monthlyData && (
            <Bar
              data={{
                labels: monthlyData.labels,
                datasets: [
                  {
                    label: "Work Hours",
                    data: monthlyData.work_data,
                    backgroundColor: "blue",
                  },
                  {
                    label: "Leave Days",
                    data: monthlyData.leave_data,
                    backgroundColor: "red",
                  },
                ],
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default HrSupervisorChart;