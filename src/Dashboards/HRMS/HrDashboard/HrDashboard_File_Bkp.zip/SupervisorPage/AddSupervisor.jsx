import axios from "axios";
import React from "react";
import { useForm } from "react-hook-form"; // Import useForm from react-hook-form
import { toast } from "react-toastify";

const apiBaseUrl = process.env.VITE_BASE_API;

const AddSupervisor = ({ setAddSupervisorPopup, fetchSupervisorList, ShiftList, DepartmentList }) => {
  const {
    register, // Register the form inputs
    handleSubmit, // Handle the form submission
    formState: { errors }, // Access the errors object for validation messages
  } = useForm();

  // Submit function for form data
  const HandleAddSupervisor = async (data) => {
    try {
      const formData = new FormData();
      formData.append('supervisor_name', data.supervisor_name);
      formData.append('email', data.email);
      formData.append('gender', data.gender);
      formData.append('dob', data.dob);
      formData.append('supervisor_image', data.supervisor_image[0]);
      formData.append('supervisor_id', data.supervisor_id);
      formData.append('username', data.username);
      formData.append('password', data.password);
      formData.append('department', data.department);
      formData.append('shift', data.shift);
      formData.append('hired_date', data.hired_date);

      const { data: response } = await axios.post(
        $`{apiBaseUrl}/admin/supervisor/add/`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      setAddSupervisorPopup(false);
      fetchSupervisorList();
      toast.success($`{response}`);
    } catch (error) {
      console.error(error);
      toast.error(`Failed to add Supervisor`);
    }
  };

  return (
    <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
        <h1 className="text-2xl font-semibold mb-6">Add Supervisor</h1>
        <form onSubmit={handleSubmit(HandleAddSupervisor)} className="space-y-4">
          {/* Personal Details Section */}
          <h2 className="font-medium text-gray-700">Personal Details</h2>
          <div className="space-y-4">
            {/* Supervisor Name */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Name</label>
              <input
                type="text"
                placeholder="Enter name"
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("supervisor_name", {
                  required: { value: true, message: "Supervisor name is required" },
                  pattern: {
                    value: /^[A-Z][a-z](\s[A-Z][a-z])*$/, // Regex for capital first letter
                    message: "Name must start with a capital letter and can have multiple capitalized words",
                  },
                })}
              />
              {errors.supervisor_name && (
                <span className="text-red-500 text-sm">{errors.supervisor_name.message}</span>
              )}
            </div>
            {/* Email */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Email</label>
              <input
                type="email"
                placeholder="Enter Email Address"
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("email", {
                  required: { value: true, message: "Email is required" },
                  pattern: {
                    value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                    message: "Invalid email address",
                  },
                })}
              />
              {errors.email && <span className="text-red-500 text-sm">{errors.email.message}</span>}
            </div>
            {/* Gender */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Gender</label>
              <select
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("gender", { required: "Gender is required" })}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
              {errors.gender && (
                <span className="text-red-500 text-sm">{errors.gender.message}</span>
              )}
            </div>
            {/* Date of Birth */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Date of Birth</label>
              <input
                type="date"
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("dob", { required: "Date of Birth is required" })}
              />
              {errors.dob && <span className="text-red-500 text-sm">{errors.dob.message}</span>}
            </div>
            {/* Profile Image */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Profile Image</label>
              <input
                type="file"
                accept="image/*"
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("supervisor_image", { required: "Profile image is required" })}
              />
              {errors.supervisor_image && (
                <span className="text-red-500 text-sm">{errors.supervisor_image.message}</span>
              )}
            </div>
          </div>

          {/* Work Details Section */}
          <h2 className="font-medium text-gray-700">Work Details</h2>
          <div className="space-y-4">
            {/* Supervisor ID */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">User ID</label>
              <input
                type="text"
                placeholder="Enter User Id"
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("supervisor_id", {
                  required: { value: true, message: "User ID is required" },
                  pattern: {
                    value: /^[a-zA-Z0-9]{6,10}$/, // Regex for 6-10 alphanumeric characters
                    message: "User ID must be 6-10 alphanumeric characters",
                  },
                })}
              />
              {errors.supervisor_id && (
                <span className="text-red-500 text-sm">{errors.supervisor_id.message}</span>
              )}
            </div>
            {/* Username */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Username</label>
              <input
                type="text"
                placeholder="Enter Username"
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("username", {
                  required: { value: true, message: "Username is required" },
                  pattern: {
                    value: /^[a-zA-Z0-9]{3,15}$/, // Regex for 3-15 alphanumeric characters
                    message: "Username must be 3-15 alphanumeric characters",
                  },
                })}
              />
              {errors.username && (
                <span className="text-red-500 text-sm">{errors.username.message}</span>
              )}
            </div>
            {/* Password */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Password</label>
              <input
                type="password"
                placeholder="Enter User password"
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("password", {
                  required: { value: true, message: "Password is required" },
                  minLength: {
                    value: 6,
                    message: "Password should be at least 6 characters",
                  },
                  pattern: {
                    value: /^[A-Z][a-zA-Z0-9]*$/, // Regex for capital first letter in password
                    message: "Password should start with a capital letter and contain only letters and numbers",
                  },
                })}
              />
              {errors.password && (
                <span className="text-red-500 text-sm">{errors.password.message}</span>
              )}
            </div>
            {/* Department */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Department</label>
              <select
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("department", { required: "Department is required" })}
              >
                <option value="">Select Department</option>
                {DepartmentList.map((department) => (
                  <option key={department.id} value={department.id}>
                    {department.department_name}
                  </option>
                ))}
              </select>
              {errors.department && (
                <span className="text-red-500 text-sm">{errors.department.message}</span>
              )}
            </div>
            {/* Shift */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Shift</label>
              <select
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("shift", { required: "Shift is required" })}
              >
                <option value="">Select Shift</option>
                {ShiftList.map((shift) => (
                  <option key={shift.shift_number} value={shift.id}>
                    {shift.shift_number}
                  </option>
                ))}
              </select>
              {errors.shift && (
                <span className="text-red-500 text-sm">{errors.shift.message}</span>
              )}
            </div>
            {/* Hired Date */}
            <div className="grid grid-cols-3 items-center gap-2 w-full">
              <label className="text-sm font-medium">Hired Date</label>
              <input
                type="date"
                className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                {...register("hired_date", { required: "Hired date is required" })}
              />
              {errors.hired_date && (
                <span className="text-red-500 text-sm">{errors.hired_date.message}</span>
              )}
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="flex justify-end gap-4 mt-8">
            <button
              type="button"
              onClick={() => setAddSupervisorPopup(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddSupervisor;
