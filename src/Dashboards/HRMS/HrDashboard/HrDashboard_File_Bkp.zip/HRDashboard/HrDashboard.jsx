import React, { useState, useEffect, useRef } from "react";

// import profile from './images/profile.png';
import up from "../images/up.png";
import down from "../images/down.png";
import "@fortawesome/fontawesome-free/css/all.min.css";

import one from "../images/Group 239.png";
import two from "../images/Ellipse 33.png";
import three from "../images/Ellipse 33 (1).png";
import axios from "axios";

const HrDashboard = () => {
  return (
    <>
      <div id="mainContent">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Total Employees Card */}
          <div className="col-span-1 mb-3">
            <div className="flex flex-col bg-white shadow-lg rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="text-lg font-semibold">Total Employees</h5>
                  <p className="text-3xl mb-3">150</p>
                </div>
                <i className="bi bi-person-fill text-4xl"></i>
              </div>
              <p className="flex items-center text-green-500">
                <img src={up} alt="up" width={25} />
                <span>+10% Than last year</span>
              </p>
            </div>
          </div>

          {/* On Leave Employees Card */}
          <div className="col-span-1 mb-3">
            <div className="flex flex-col bg-white shadow-lg rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="text-lg font-semibold">On Leave Employees</h5>
                  <p className="text-3xl mb-3">560</p>
                </div>
                <i className="bi bi-person-dash text-4xl"></i>
              </div>
              <p className="flex items-center text-red-500">
                <img src={down} alt="down" width={25} />
                <span>-10% Than average last month</span>
              </p>
            </div>
          </div>

          {/* New Employees Card */}
          <div className="col-span-1 mb-3">
            <div className="flex flex-col bg-white shadow-lg rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="text-lg font-semibold">New Employees</h5>
                  <p className="text-3xl mb-3">23</p>
                </div>
                <i className="bi bi-person-plus text-4xl"></i>
              </div>
              <p className="flex items-center text-green-500">
                <img src={up} alt="up" width={25} />
                <span>+10% Than average last month</span>
              </p>
            </div>
          </div>

          {/* Resigned Employees Card */}
          <div className="col-span-1 mb-3">
            <div className="flex flex-col bg-white shadow-lg rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h5 className="text-lg font-semibold">Resigned Employees</h5>
                  <p className="text-3xl mb-3">30</p>
                </div>
                <i className="bi bi-person-x text-4xl"></i>
              </div>
              <p className="flex items-center text-red-500">
                <img src={down} alt="down" width={25} />
                <span>-10% Than last month</span>
              </p>
            </div>
          </div>

          {/* Attendance Chart with Dropdown */}
          <div className="col-span-4 mb-3">
            <div className="bg-white shadow-sm rounded p-4">
              <div className="flex justify-between items-center">
                <h5 className="text-lg font-semibold">
                  Attendance Comparison Chart
                </h5>
                <select className="border border-gray-300 rounded px-2 py-1">
                  <option value="day">Day</option>
                  <option value="month">Monthly</option>
                  <option value="year">Yearly</option>
                </select>
              </div>
              {/* <AttendanceChart /> */}
            </div>
          </div>

          {/* Approval Table */}
          <div className="col-span-3 mb-3">
            <div className="bg-white shadow-sm rounded p-4">
              <h5 className="text-lg font-semibold mb-2">Approval</h5>
              <div className="overflow-x-auto">
                <table className="min-w-full table-auto">
                  <thead className="text-gray-500">
                    <tr>
                      <th className="px-4 py-2">DATE OF APPLICATION</th>
                      <th className="px-4 py-2">APPLICANT</th>
                      <th className="px-4 py-2">APPLICATION TYPE</th>
                      <th className="px-4 py-2">DURATION</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>03/07/2021</td>
                      <td>
                        <span className="text-blue-600 font-semibold">
                          Keza Ana
                        </span>
                        <br />
                        <small className="text-gray-500">Project Manager</small>
                      </td>
                      <td>Casual leave</td>
                      <td>02 (05–06 Jul)</td>
                    </tr>
                    <tr>
                      <td>01/07/2022</td>
                      <td>
                        <span className="text-blue-600 font-semibold">
                          Hirwa Patrick
                        </span>
                        <br />
                        <small className="text-gray-500">
                          Software Developer
                        </small>
                      </td>
                      <td>Late entry</td>
                      <td>01 (06 Jul)</td>
                    </tr>
                    <tr>
                      <td>27/06/2022</td>
                      <td>
                        <span className="text-blue-600 font-semibold">
                          Mugabo Peter
                        </span>
                        <br />
                        <small className="text-gray-500">
                          Nursing Assistant
                        </small>
                      </td>
                      <td>Paternity leave</td>
                      <td>05 (05–06 Jul)</td>
                    </tr>
                    <tr>
                      <td>27/06/2022</td>
                      <td>
                        <span className="text-blue-600 font-semibold">
                          Amata
                        </span>
                        <br />
                        <small className="text-gray-500">
                          Nursing Assistant
                        </small>
                      </td>
                      <td>Paternity leave</td>
                      <td>05 (05–06 Jul)</td>
                    </tr>
                  </tbody>
                </table>
                <div className="flex">
                  <div className="mr-4">
                    <i className="fas fa-square text-blue-600"></i> Approved
                  </div>
                  <div className="mr-4">
                    <i className="fas fa-square text-red-600"></i> Rejected
                  </div>
                  <div>
                    <i className="fas fa-square text-yellow-600"></i> Pending
                  </div>
                </div>
              </div>
            </div>
            <EmployeeTable />
          </div>

          {/* Calendar */}
          <div className="col-span-1 mb-3">
            <Calendar />
          </div>
        </div>
      </div>
    </>
  );
};

const EmployeeTable = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const baseApiUrl = import.meta.env.VITE_BASE_API; // Ensure your environment variable is set
        const response = await axios.get(`${baseApiUrl}/admin/employees/`);
        const data = response.data.map((employee, index) => ({
          name: employee.employee_name || "Unknown",
          department: employee.department || "Unknown",
          age:
            new Date().getFullYear() - new Date(employee.dob).getFullYear() ||
            "Unknown",
          onTime: "09:00 AM", // Replace this with actual on-time data if available in API
          status: index % 2 === 0 ? "On-time" : "Late", // Dummy status, replace with actual status
          image: [one, two, three][index % 3], // Alternate between dummy images
        }));
        setEmployees(data);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching employee data", err);
        setError("Failed to load employee data.");
        setLoading(false);
      }
    };

    fetchEmployees();
  }, []);

  const getBadgeClass = (status) => {
    switch (status) {
      case "On-time":
        return "bg-green-100 text-green-600 px-3 py-1 rounded-full text-xs";
      case "Late":
        return "bg-red-100 text-red-600 px-3 py-1 rounded-full text-xs";
      default:
        return "bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs";
    }
  };

  return (
    <>
      <div className="employee-status p-4">
        <h5 className="text-xl font-semibold mb-4">Employee Status</h5>
        {loading && <p>Loading...</p>}
        {error && <p className="text-red-500">{error}</p>}
        {!loading && !error && (
          <div className="table-container overflow-x-auto max-h-80">
            <table className="min-w-full table-auto border-separate border-spacing-2">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left px-4 py-2 text-sm font-medium text-gray-700">
                    Employee Name
                  </th>
                  <th className="text-left px-4 py-2 text-sm font-medium text-gray-700">
                    Department
                  </th>
                  <th className="text-left px-4 py-2 text-sm font-medium text-gray-700">
                    Age
                  </th>
                  <th className="text-left px-4 py-2 text-sm font-medium text-gray-700">
                    On-time
                  </th>
                  <th className="text-center px-4 py-2 text-sm font-medium text-gray-700">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {employees.map((employee, index) => (
                  <tr key={index} className="hover:bg-gray-100">
                    <td className="px-4 py-2 text-sm font-medium text-gray-800 flex items-center">
                      <img
                        src={employee.image}
                        alt={`${employee.name} logo`}
                        className="w-8 h-8 rounded-full mr-3"
                      />
                      {employee.name}
                    </td>
                    <td className="px-4 py-2 text-sm font-medium text-gray-800">
                      {employee.department}
                    </td>
                    <td className="px-4 py-2 text-sm font-medium text-gray-800">
                      {employee.age}
                    </td>
                    <td className="px-4 py-2 text-sm font-medium text-gray-800">
                      {employee.onTime}
                    </td>
                    <td className="text-center px-4 py-2">
                      <span className={getBadgeClass(employee.status)}>
                        {employee.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
};

const Calendar = () => {
  const events = [
    {
      time: "10:00 AM",
      title: "Team meeting",
      duration: "10:00 AM - 11:00 AM",
    },
    { time: "1:00 PM", title: "Client meeting", duration: "1:00 PM - 2:00 PM" },
    {
      time: "4:00 PM",
      title: "Project discussion",
      duration: "4:00 PM - 5:00 PM",
    },
  ];

  // Function to generate time slots from 9:00 AM to 5:00 PM
  const generateTimeSlots = (startHour, endHour) => {
    const slots = [];
    let period = "AM";
    for (let hour = startHour; hour <= endHour; hour++) {
      const displayHour = hour > 12 ? hour - 12 : hour; // Convert to 12-hour format
      if (hour === 12) period = "PM"; // Switch to PM at 12:00
      slots.push(`${displayHour}:00 ${period}`);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots(9, 17); // Generate time slots from 9:00 AM to 5:00 PM

  return (
    <div className="bg-white shadow-lg rounded-lg mb-3">
      <div className="p-4">
        {/* Header */}
        <div className="flex justify-between items-center mb-4 px-2">
          <h5 className="text-xl font-semibold">Calendar</h5>
        </div>
        {/* Month and Navigation */}
        <div className="flex justify-between items-center p-2 rounded bg-gray-100">
          <span className="text-lg">Aug 2024</span>
          <button className="btn bg-white border btn-sm text-blue-500">
            Add reminder +
          </button>
        </div>
        {/* Date Selection */}
        <div className="flex justify-between items-center mt-4 mb-6 bg-gray-100 p-2 rounded">
          {[...Array(7)].map((_, index) => (
            <div
              key={index}
              className={`text-center p-2 rounded cursor-pointer ${
                index === 3 ? "bg-blue-500 text-white" : "text-gray-500"
              }`}
            >
              <small>{16 + index}</small>
              <div>
                {["Mon", "Tue", "Wed", "Thur", "Fri", "Sat", "Sun"][index]}
              </div>
            </div>
          ))}
        </div>
        {/* Event List */}
        <div className="px-3">
          {timeSlots.map((time, index) => {
            const event = events.find((e) => e.time === time); // Check if there's an event at this time slot
            return (
              <div key={index} className="flex items-center mb-3">
                <div className="mr-4 text-gray-500" style={{ width: "80px" }}>
                  {time}
                </div>
                <div className="flex-grow">
                  {event ? (
                    <div className="bg-white shadow-md border rounded p-3 flex justify-between items-center">
                      <div>
                        <h6 className="text-sm font-semibold">{event.title}</h6>
                        <small className="text-gray-500">
                          {event.duration}
                        </small>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600 p-0 ml-2">
                        <i className="bi bi-three-dots"></i>
                      </button>
                    </div>
                  ) : (
                    <hr className="border-t border-gray-300" />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default HrDashboard;
